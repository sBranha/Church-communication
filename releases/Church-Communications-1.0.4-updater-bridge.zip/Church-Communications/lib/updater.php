<?php
declare(strict_types=1);

function cc_http_get(string $url,int $timeout=20,bool $fresh=false): string {
    if(!preg_match('#^https://#i',$url)) throw new RuntimeException('Update URLs must use HTTPS.');
    if($fresh)$url.=(str_contains($url,'?')?'&':'?').'cc_cache_bust='.rawurlencode(CC_VERSION.'-'.time());
    if(function_exists('curl_init')){
        $ch=curl_init($url);curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_MAXREDIRS=>5,CURLOPT_CONNECTTIMEOUT=>8,CURLOPT_TIMEOUT=>$timeout,CURLOPT_USERAGENT=>'ChurchCommunications/'.CC_VERSION,CURLOPT_HTTPHEADER=>['Cache-Control: no-cache','Pragma: no-cache']]);
        $body=curl_exec($ch);$code=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);$err=curl_error($ch);curl_close($ch);
        if($body===false||$code<200||$code>=300)throw new RuntimeException('Update download failed'.($err?': '.$err:'').' (HTTP '.$code.').');
        return (string)$body;
    }
    if(!ini_get('allow_url_fopen'))throw new RuntimeException('This server needs PHP cURL or allow_url_fopen enabled for automatic updates.');
    $ctx=stream_context_create(['http'=>['timeout'=>$timeout,'follow_location'=>1,'user_agent'=>'ChurchCommunications/'.CC_VERSION,'header'=>"Cache-Control: no-cache\r\nPragma: no-cache\r\n"]]);
    $body=@file_get_contents($url,false,$ctx);if($body===false)throw new RuntimeException('Update download failed.');return $body;
}

function cc_update_manifest(?string $url=null): array {
    $url=trim($url??(string)cc_setting('update_manifest_url',''));if($url==='')throw new RuntimeException('Set the Update Feed URL first.');
    $m=json_decode(cc_http_get($url,15,true),true);if(!is_array($m))throw new RuntimeException('The update feed did not return valid JSON.');
    if(empty($m['version'])||!is_string($m['version'])||!preg_match('/^\d+\.\d+\.\d+(?:[-+][A-Za-z0-9.-]+)?$/',$m['version']))throw new RuntimeException('Update feed has an invalid version number.');
    $mode=(string)($m['mode']??(isset($m['files'])?'files':'zip'));
    if($mode==='files'){
        if(empty($m['files'])||!is_array($m['files']))throw new RuntimeException('Update feed is missing files.');
        foreach($m['files'] as $f){if(!is_array($f)||empty($f['path'])||empty($f['url'])||empty($f['sha256']))throw new RuntimeException('Update feed has an invalid file entry.');cc_update_validate_relpath((string)$f['path']);if(!preg_match('#^https://#i',(string)$f['url']))throw new RuntimeException('Update file URLs must use HTTPS.');if(!preg_match('/^[a-f0-9]{64}$/i',(string)$f['sha256']))throw new RuntimeException('Update feed has an invalid file checksum.');}
    } else {
        foreach(['zip_url','sha256'] as $k)if(empty($m[$k])||!is_string($m[$k]))throw new RuntimeException('Update feed is missing '.$k.'.');
        if(!preg_match('#^https://#i',$m['zip_url']))throw new RuntimeException('Update package URL must use HTTPS.');
        if(!preg_match('/^[a-f0-9]{64}$/i',$m['sha256']))throw new RuntimeException('Update feed has an invalid SHA-256 checksum.');
    }
    $m['mode']=$mode;return $m;
}

function cc_update_validate_relpath(string $rel): void {
    $rel=str_replace('\\','/',$rel);if($rel===''||str_starts_with($rel,'/')||str_contains('/'.$rel,'/../')||str_contains($rel,"\0"))throw new RuntimeException('Unsafe path found in update.');
    if($rel==='data'||str_starts_with($rel,'data/'))throw new RuntimeException('Updates may not replace the data folder.');
}
function cc_recursive_remove(string $path): void {if(!file_exists($path))return;if(is_file($path)||is_link($path)){@unlink($path);return;}$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST);foreach($it as $f){$f->isDir()?@rmdir($f->getPathname()):@unlink($f->getPathname());}@rmdir($path);}
function cc_update_backup_db(string $stamp): string {$d=CC_DATA_DIR.'/backups';if(!is_dir($d)&&!mkdir($d,0775,true)&&!is_dir($d))throw new RuntimeException('Could not create backup folder.');$p=$d.'/pre-update-'.$stamp.'.sqlite';@unlink($p);cc_db()->exec('VACUUM INTO '.cc_db()->quote($p));if(!is_file($p)||filesize($p)<1)throw new RuntimeException('SQLite backup could not be verified.');return $p;}
function cc_update_php_lint(string $file): void {if(!str_ends_with(strtolower($file),'.php'))return;$disabled=array_map('trim',explode(',',(string)ini_get('disable_functions')));if(in_array('exec',$disabled,true)||!function_exists('exec'))return;$out=[];$code=0;@exec(escapeshellarg(PHP_BINARY).' -l '.escapeshellarg($file).' 2>&1',$out,$code);if($code!==0)throw new RuntimeException('PHP validation failed for '.basename($file).'.');}
function cc_update_restore(array $backups,array $created): void {foreach(array_reverse($created) as $rel)@unlink(CC_ROOT.'/'.$rel);foreach($backups as $rel=>$bak){if(is_file($bak)){if(!is_dir(dirname(CC_ROOT.'/'.$rel)))@mkdir(dirname(CC_ROOT.'/'.$rel),0775,true);@copy($bak,CC_ROOT.'/'.$rel);}}}
function cc_update_apply_files(array $manifest,string $stamp,string $work): array {
    $stage=$work.'/stage-'.$stamp;$rollback=$work.'/rollback-'.$stamp;@mkdir($stage,0775,true);@mkdir($rollback,0775,true);$staged=[];
    foreach($manifest['files'] as $f){$rel=str_replace('\\','/',(string)$f['path']);cc_update_validate_relpath($rel);$dest=$stage.'/'.$rel;if(!is_dir(dirname($dest))&&!mkdir(dirname($dest),0775,true)&&!is_dir(dirname($dest)))throw new RuntimeException('Could not create staging folder.');$body=cc_http_get((string)$f['url'],45,true);file_put_contents($dest,$body,LOCK_EX);$actual=hash_file('sha256',$dest);if(!hash_equals(strtolower((string)$f['sha256']),strtolower($actual)))throw new RuntimeException('Update file checksum did not match for '.$rel.'. Installation stopped.');cc_update_php_lint($dest);$staged[$rel]=$dest;}
    $backups=[];$created=[];try{
        foreach($staged as $rel=>$src){$target=CC_ROOT.'/'.$rel;if(file_exists($target)){$bak=$rollback.'/'.$rel;if(!is_dir(dirname($bak)))mkdir(dirname($bak),0775,true);if(!copy($target,$bak))throw new RuntimeException('Could not back up '.$rel);$backups[$rel]=$bak;}else{$created[]=$rel;}if(!is_dir(dirname($target)))mkdir(dirname($target),0775,true);if(!copy($src,$target))throw new RuntimeException('Could not install '.$rel);}
        if(isset($manifest['sql'])&&is_array($manifest['sql'])&&$manifest['sql']){$db=cc_db();$db->beginTransaction();try{foreach($manifest['sql'] as $sql){if(!is_string($sql)||trim($sql)==='')continue;$db->exec($sql);}$db->commit();}catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}}
        if(is_file(CC_ROOT.'/config.php')){$cfg=file_get_contents(CC_ROOT.'/config.php');if($cfg===false||!str_contains($cfg,"'".$manifest['version']."'"))throw new RuntimeException('Installed version verification failed.');}
    }catch(Throwable $e){cc_update_restore($backups,$created);throw $e;}
    cc_recursive_remove($stage);cc_recursive_remove($rollback);return array_keys($staged);
}
function cc_update_apply_zip(array $manifest,string $stamp,string $work): void {
    if(!class_exists('ZipArchive'))throw new RuntimeException('PHP ZipArchive is required for ZIP updates.');$zipPath=$work.'/update-'.$stamp.'.zip';$body=cc_http_get($manifest['zip_url'],60,true);file_put_contents($zipPath,$body,LOCK_EX);$actual=hash_file('sha256',$zipPath);if(!hash_equals(strtolower($manifest['sha256']),strtolower($actual))){@unlink($zipPath);throw new RuntimeException('Update checksum did not match. Installation stopped.');}$zip=new ZipArchive();if($zip->open($zipPath)!==true)throw new RuntimeException('Could not open the update package.');for($i=0;$i<$zip->numFiles;$i++){cc_update_validate_relpath(ltrim(str_replace('\\','/',$zip->getNameIndex($i)),'/'));}$stage=$work.'/stage-'.$stamp;if(!is_dir($stage))mkdir($stage,0775,true);if(!$zip->extractTo($stage)){$zip->close();throw new RuntimeException('Could not extract update package.');}$zip->close();$items=array_values(array_filter(scandir($stage)?:[],fn($x)=>$x!=='.'&&$x!=='..'));$src=count($items)===1&&is_dir($stage.'/'.$items[0])?$stage.'/'.$items[0]:$stage;$files=[];$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($src,FilesystemIterator::SKIP_DOTS));foreach($it as $f){if(!$f->isFile())continue;$rel=str_replace('\\','/',substr($f->getPathname(),strlen($src)+1));if($rel==='data'||str_starts_with($rel,'data/'))continue;$files[]=['path'=>$rel,'url'=>'','sha256'=>hash_file('sha256',$f->getPathname()),'_local'=>$f->getPathname()];}if(!is_file($src.'/config.php')||!is_file($src.'/lib/bootstrap.php'))throw new RuntimeException('Update package is not a Church Communications package.');$rollback=$work.'/rollback-'.$stamp;@mkdir($rollback,0775,true);$backups=[];$created=[];try{foreach($files as $f){$rel=$f['path'];$target=CC_ROOT.'/'.$rel;if(file_exists($target)){$bak=$rollback.'/'.$rel;if(!is_dir(dirname($bak)))mkdir(dirname($bak),0775,true);copy($target,$bak);$backups[$rel]=$bak;}else$created[]=$rel;cc_update_php_lint($f['_local']);if(!is_dir(dirname($target)))mkdir(dirname($target),0775,true);if(!copy($f['_local'],$target))throw new RuntimeException('Could not install '.$rel);}}catch(Throwable $e){cc_update_restore($backups,$created);throw $e;}cc_recursive_remove($stage);cc_recursive_remove($rollback);@unlink($zipPath);
}
function cc_install_update(array $manifest): array {
    if(version_compare($manifest['version'],CC_VERSION,'<='))return ['installed'=>false,'message'=>'Church Communications is already up to date.'];if(!is_writable(CC_ROOT))throw new RuntimeException('The website folder is not writable by PHP.');$work=CC_DATA_DIR.'/updates';if(!is_dir($work)&&!mkdir($work,0775,true)&&!is_dir($work))throw new RuntimeException('Could not create update workspace.');$stamp=date('Ymd-His');$dbBackup=cc_update_backup_db($stamp);
    try{if(($manifest['mode']??'zip')==='files')cc_update_apply_files($manifest,$stamp,$work);else cc_update_apply_zip($manifest,$stamp,$work);cc_set_setting('version',$manifest['version']);cc_set_setting('last_update_at',gmdate('c'));cc_set_setting('last_update_version',$manifest['version']);cc_db()->prepare("INSERT INTO audit_log(actor_type,action,details) VALUES('system','update_installed',?)")->execute(['Version '.$manifest['version']]);}catch(Throwable $e){throw new RuntimeException($e->getMessage().' Your pre-update SQLite backup is '.$dbBackup.'.');}
    return ['installed'=>true,'version'=>$manifest['version'],'backup'=>$dbBackup,'message'=>'Updated to '.$manifest['version'].'.'];
}
