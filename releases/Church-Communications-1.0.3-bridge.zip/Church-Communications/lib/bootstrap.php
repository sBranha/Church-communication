<?php
declare(strict_types=1);
require_once __DIR__.'/../config.php';
require_once __DIR__.'/db.php';
require_once __DIR__.'/auth.php';
require_once __DIR__.'/push.php';
require_once __DIR__.'/migrations.php';
if (cc_installed()) cc_run_migrations(cc_db());

function cc_h(string $s): string { return htmlspecialchars($s,ENT_QUOTES,'UTF-8'); }
function cc_base_url(): string {
    $https=!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off';
    $scheme=$https?'https':'http'; $host=$_SERVER['HTTP_HOST'] ?? 'localhost';
    $dir=rtrim(str_replace('\\','/',dirname($_SERVER['SCRIPT_NAME'] ?? '/')),'/');
    return $scheme.'://'.$host.($dir==='/'?'':$dir);
}
function cc_member_key(string $type,int $id): string { return $type.':'.$id; }
function cc_identity_name(string $type,int $id): string {
    if ($type==='user') {$s=cc_db()->prepare('SELECT display_name FROM users WHERE id=?');}
    else {$s=cc_db()->prepare('SELECT name FROM locations WHERE id=?');}
    $s->execute([$id]); return (string)($s->fetchColumn() ?: 'Unknown');
}
function cc_thread_has_member(int $threadId,array $ident): bool {
    $s=cc_db()->prepare('SELECT 1 FROM thread_members WHERE thread_id=? AND member_type=? AND member_id=?');
    $s->execute([$threadId,$ident['type'],$ident['id']]); return (bool)$s->fetchColumn();
}
function cc_touch_read(int $threadId,array $ident,int $messageId): void {
    $s=cc_db()->prepare('INSERT INTO read_receipts(thread_id,member_type,member_id,last_read_message_id,updated_at) VALUES(?,?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(thread_id,member_type,member_id) DO UPDATE SET last_read_message_id=max(last_read_message_id,excluded.last_read_message_id),updated_at=CURRENT_TIMESTAMP');
    $s->execute([$threadId,$ident['type'],$ident['id'],$messageId]);
}
