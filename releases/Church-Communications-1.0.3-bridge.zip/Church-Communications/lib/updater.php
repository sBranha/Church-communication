<?php
declare(strict_types=1);

function cc_http_get(string $url,int $timeout=20): string {
    if (!preg_match('#^https://#i',$url)) throw new RuntimeException('Update URLs must use HTTPS.');
    if (function_exists('curl_init')) {
        $ch=curl_init($url);
        curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_MAXREDIRS=>5,CURLOPT_CONNECTTIMEOUT=>8,CURLOPT_TIMEOUT=>$timeout,CURLOPT_USERAGENT=>'ChurchCommunications/'.CC_VERSION]);
        $body=curl_exec($ch); $code=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE); $err=curl_error($ch); curl_close($ch);
        if ($body===false || $code<200 || $code>=300) throw new RuntimeException('Update download failed'.($err?': '.$err:'').' (HTTP '.$code.').');
        return (string)$body;
    }
    if (!ini_get('allow_url_fopen')) throw new RuntimeException('This server needs PHP cURL or allow_url_fopen enabled for automatic updates.');
    $ctx=stream_context_create(['http'=>['timeout'=>$timeout,'follow_location'=>1,'user_agent'=>'ChurchCommunications/'.CC_VERSION]]);
    $body=@file_get_contents($url,false,$ctx);
    if ($body===false) throw new RuntimeException('Update download failed.');
    return $body;
}

function cc_update_manifest(?string $url=null): array {
    $url=trim($url ?? (string)cc_setting('update_manifest_url',''));
    if ($url==='') throw new RuntimeException('Set the Update Feed URL first.');
    $raw=cc_http_get($url,15);
    $m=json_decode($raw,true);
    if (!is_array($m)) throw new RuntimeException('The update feed did not return valid JSON.');
    if(empty($m['version'])||!is_string($m['version'])) throw new RuntimeException('Update feed is missing version.');
    if (!preg_match('/^\d+\.\d+\.\d+(?:[-+][A-Za-z0-9.-]+)?$/',$m['version'])) throw new RuntimeException('Update feed has an invalid version number.');
    if (!empty($m['files'])) {
        if (!is_array($m['files'])) throw new RuntimeException('Update feed files list is invalid.');
        foreach ($m['files'] as $f) {
            if (!is_array($f) || empty($f['path']) || empty($f['url']) || empty($f['sha256'])) throw new RuntimeException('Update feed has an invalid file entry.');
            $path=str_replace('\\','/',(string)$f['path']);
            if (str_starts_with($path,'/') || str_contains('/'.$path,'/../') || $path==='data' || str_starts_with($path,'data/')) throw new RuntimeException('Update feed contains an unsafe file path.');
            if (!preg_match('#^https://#i',(string)$f['url'])) throw new RuntimeException('Update file URLs must use HTTPS.');
            if (!preg_match('/^[a-f0-9]{64}$/i',(string)$f['sha256'])) throw new RuntimeException('Update feed has an invalid file checksum.');
        }
        return $m;
    }
    foreach(['zip_url','sha256'] as $k) if(empty($m[$k])||!is_string($m[$k])) throw new RuntimeException('Update feed is missing '.$k.'.');
    if (!preg_match('#^https://#i',$m['zip_url'])) throw new RuntimeException('Update package URL must use HTTPS.');
    if (!preg_match('/^[a-f0-9]{64}$/i',$m['sha256'])) throw new RuntimeException('Update feed has an invalid SHA-256 checksum.');
    return $m;
}

function cc_recursive_remove(string $path): void {
    if (!file_exists($path)) return;
    if (is_file($path)||is_link($path)) { @unlink($path); return; }
    $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST);
    foreach($it as $f){ if($f->isDir())@rmdir($f->getPathname());else @unlink($f->getPathname()); }
    @rmdir($path);
}

function cc_copy_tree(string $src,string $dst,array &$changed,array &$created,string $backupRoot): void {
    $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($src,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::SELF_FIRST);
    foreach($it as $f){
        $rel=str_replace('\\','/',substr($f->getPathname(),strlen($src)+1));
        if ($rel==='data'||str_starts_with($rel,'data/')) continue;
        if ($rel===''||str_contains($rel,'../')) continue;
        $target=$dst.'/'.$rel;
        if ($f->isDir()) { if(!is_dir($target)&&!mkdir($target,0775,true)&&!is_dir($target)) throw new RuntimeException('Could not create '.$rel); continue; }
        if (file_exists($target)) {
            $backup=$backupRoot.'/'.$rel; if(!is_dir(dirname($backup)))mkdir(dirname($backup),0775,true);
            if(!copy($target,$backup))throw new RuntimeException('Could not back up '.$rel); $changed[]=$rel;
        } else $created[]=$rel;
        if(!is_dir(dirname($target)))mkdir(dirname($target),0775,true);
        if(!copy($f->getPathname(),$target))throw new RuntimeException('Could not install '.$rel);
    }
}

function cc_restore_update(array $changed,array $created,string $backupRoot): void {
    foreach(array_reverse($created) as $rel) @unlink(CC_ROOT.'/'.$rel);
    foreach($changed as $rel){$b=$backupRoot.'/'.$rel;if(is_file($b)){if(!is_dir(dirname(CC_ROOT.'/'.$rel)))mkdir(dirname(CC_ROOT.'/'.$rel),0775,true);@copy($b,CC_ROOT.'/'.$rel);}}
}

function cc_install_update(array $manifest): array {
    if (version_compare($manifest['version'],CC_VERSION,'<=')) return ['installed'=>false,'message'=>'Church Communications is already up to date.'];
    if (!is_writable(CC_ROOT)) throw new RuntimeException('The website folder is not writable by PHP.');
    $work=CC_DATA_DIR.'/updates'; if(!is_dir($work))mkdir($work,0775,true);
    $stamp=date('Ymd-His'); $stage=$work.'/stage-'.$stamp; $backupRoot=$work.'/rollback-'.$stamp;
    if(!is_dir($stage))mkdir($stage,0775,true);

    if (!empty($manifest['files'])) {
        foreach ($manifest['files'] as $f) {
            $rel=str_replace('\\','/',(string)$f['path']); $target=$stage.'/'.$rel;
            if(!is_dir(dirname($target)))mkdir(dirname($target),0775,true);
            $body=cc_http_get((string)$f['url'],60);
            if (!hash_equals(strtolower((string)$f['sha256']),strtolower(hash('sha256',$body)))) throw new RuntimeException('Checksum did not match for '.$rel.'. Installation stopped.');
            if(file_put_contents($target,$body,LOCK_EX)===false) throw new RuntimeException('Could not stage '.$rel.'.');
        }
        $source=$stage;
    } else {
        if (!class_exists('ZipArchive')) throw new RuntimeException('PHP ZipArchive is required for ZIP updates.');
        $zipPath=$work.'/update-'.$stamp.'.zip';
        $body=cc_http_get($manifest['zip_url'],60); file_put_contents($zipPath,$body,LOCK_EX);
        $actual=hash_file('sha256',$zipPath); if(!hash_equals(strtolower($manifest['sha256']),strtolower($actual))){@unlink($zipPath);throw new RuntimeException('Update checksum did not match. Installation stopped.');}
        $zip=new ZipArchive();if($zip->open($zipPath)!==true)throw new RuntimeException('Could not open the update package.');
        for($i=0;$i<$zip->numFiles;$i++){ $n=str_replace('\\','/',$zip->getNameIndex($i)); if(str_starts_with($n,'/')||str_contains('/'.$n,'/../')){$zip->close();throw new RuntimeException('Unsafe path found in update package.');} }
        if(!$zip->extractTo($stage)){$zip->close();throw new RuntimeException('Could not extract update package.');}$zip->close();
        $source=$stage; $items=array_values(array_filter(scandir($stage)?:[],fn($x)=>$x!=='.'&&$x!=='..'));
        if(count($items)===1 && is_dir($stage.'/'.$items[0]))$source=$stage.'/'.$items[0];
        @unlink($zipPath);
    }

    if(!is_file($source.'/config.php')||!is_file($source.'/lib/bootstrap.php'))throw new RuntimeException('Update package is not a Church Communications package.');
    $db=cc_db(); $backupDir=CC_DATA_DIR.'/backups';if(!is_dir($backupDir))mkdir($backupDir,0775,true);$dbBackup=$backupDir.'/pre-update-'.$stamp.'.sqlite';@unlink($dbBackup);$db->exec('VACUUM INTO '.$db->quote($dbBackup));
    $changed=[];$created=[];if(!is_dir($backupRoot))mkdir($backupRoot,0775,true);
    try {
        cc_copy_tree($source,CC_ROOT,$changed,$created,$backupRoot);
        require_once CC_ROOT.'/lib/migrations.php'; cc_run_migrations($db);
        cc_set_setting('version',$manifest['version']); cc_set_setting('last_update_at',gmdate('c')); cc_set_setting('last_update_version',$manifest['version']);
        $db->prepare("INSERT INTO audit_log(actor_type,action,details) VALUES('system','update_installed',?)")->execute(['Version '.$manifest['version']]);
    } catch(Throwable $e) { cc_restore_update($changed,$created,$backupRoot); throw $e; }
    cc_recursive_remove($stage); cc_recursive_remove($backupRoot);
    return ['installed'=>true,'version'=>$manifest['version'],'backup'=>$dbBackup,'message'=>'Updated to '.$manifest['version'].'.'];
}
