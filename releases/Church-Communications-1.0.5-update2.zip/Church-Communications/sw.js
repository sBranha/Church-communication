const CACHE='church-communications-v105';
const CORE=['./','index.php','assets/app.css','assets/app.js','icons/icon-192.png','icons/icon-512.png'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE&&k.startsWith('church-communications-')).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{if(e.request.method!=='GET')return;const u=new URL(e.request.url);if(u.origin!==location.origin||u.pathname.includes('api.php'))return;e.respondWith(fetch(e.request).then(r=>{const copy=r.clone();caches.open(CACHE).then(c=>c.put(e.request,copy));return r}).catch(()=>caches.match(e.request)));});
self.addEventListener('push',e=>{let d={title:'Church Communications',body:'New message',url:'./index.php',priority:'normal'};try{d={...d,...e.data.json()}}catch(_){if(e.data)d.body=e.data.text()}
 const opts={body:d.body,icon:'icons/icon-192.png',badge:'icons/icon-192.png',data:{url:d.url||'./index.php'},tag:d.tag||undefined,renotify:true,requireInteraction:d.priority==='urgent'};
 e.waitUntil(self.registration.showNotification(d.title,opts));});
self.addEventListener('notificationclick',e=>{e.notification.close();e.waitUntil(clients.matchAll({type:'window',includeUncontrolled:true}).then(ws=>{for(const w of ws){if('focus'in w){w.navigate(e.notification.data.url);return w.focus()}}return clients.openWindow(e.notification.data.url)}));});
