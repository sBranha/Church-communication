<?php
declare(strict_types=1);

function cc_table_exists(PDO $db,string $name): bool {
    $s=$db->prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?");
    $s->execute([$name]);
    return (bool)$s->fetchColumn();
}

function cc_column_exists(PDO $db,string $table,string $column): bool {
    $q=$db->query("PRAGMA table_info(".$table.")");
    foreach($q->fetchAll() as $r) if(($r['name']??'')===$column) return true;
    return false;
}

function cc_run_migrations(PDO $db): void {
    if (!cc_table_exists($db,'settings')) return;
    $db->exec("CREATE TABLE IF NOT EXISTS invites (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      token_hash TEXT NOT NULL UNIQUE,
      role TEXT NOT NULL DEFAULT 'member',
      expires_at TEXT NOT NULL,
      max_uses INTEGER NOT NULL DEFAULT 1,
      uses INTEGER NOT NULL DEFAULT 0,
      active INTEGER NOT NULL DEFAULT 1,
      created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )");
    $db->exec("CREATE TABLE IF NOT EXISTS invite_groups (
      invite_id INTEGER NOT NULL REFERENCES invites(id) ON DELETE CASCADE,
      group_id INTEGER NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
      PRIMARY KEY(invite_id,group_id)
    )");
    $db->exec("CREATE TABLE IF NOT EXISTS group_leaders (
      group_id INTEGER NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY(group_id,user_id)
    )");
    if (!cc_column_exists($db,'users','avatar_path')) $db->exec("ALTER TABLE users ADD COLUMN avatar_path TEXT");
    if (!cc_column_exists($db,'groups','image_path')) $db->exec("ALTER TABLE groups ADD COLUMN image_path TEXT");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_invites_token_hash ON invites(token_hash)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_group_members_member ON group_members(member_type,member_id,group_id)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_group_leaders_user ON group_leaders(user_id,group_id)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_thread_members_member ON thread_members(member_type,member_id,thread_id)");
    $s=$db->prepare("INSERT INTO settings(key,value) VALUES('version',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value");
    $s->execute([CC_VERSION]);
}
