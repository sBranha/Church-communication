<?php
declare(strict_types=1);
require_once __DIR__.'/../config.php';
require_once __DIR__.'/db.php';
require_once __DIR__.'/auth.php';
require_once __DIR__.'/push.php';
require_once __DIR__.'/migrations.php';
if (cc_installed()) cc_run_migrations(cc_db());

function cc_h(string $s): string { return htmlspecialchars($s,ENT_QUOTES,'UTF-8'); }
function cc_base_url(): string {
    $https=!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off';
    $scheme=$https?'https':'http'; $host=$_SERVER['HTTP_HOST'] ?? 'localhost';
    $dir=rtrim(str_replace('\\','/',dirname($_SERVER['SCRIPT_NAME'] ?? '/')),'/');
    return $scheme.'://'.$host.($dir==='/'?'':$dir);
}
function cc_member_key(string $type,int $id): string { return $type.':'.$id; }
function cc_identity_name(string $type,int $id): string {
    if ($type==='user') {$s=cc_db()->prepare('SELECT display_name FROM users WHERE id=?');}
    else {$s=cc_db()->prepare('SELECT name FROM locations WHERE id=?');}
    $s->execute([$id]); $name=$s->fetchColumn();
    if($name!==false && $name!=='') return (string)$name;
    return $type==='location' ? 'Deleted location' : 'Deleted person';
}
function cc_thread_has_member(int $threadId,array $ident): bool {
    $s=cc_db()->prepare('SELECT 1 FROM thread_members WHERE thread_id=? AND member_type=? AND member_id=?');
    $s->execute([$threadId,$ident['type'],$ident['id']]); return (bool)$s->fetchColumn();
}
function cc_touch_read(int $threadId,array $ident,int $messageId): void {
    $s=cc_db()->prepare('INSERT INTO read_receipts(thread_id,member_type,member_id,last_read_message_id,updated_at) VALUES(?,?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(thread_id,member_type,member_id) DO UPDATE SET last_read_message_id=max(last_read_message_id,excluded.last_read_message_id),updated_at=CURRENT_TIMESTAMP');
    $s->execute([$threadId,$ident['type'],$ident['id'],$messageId]);
}

function cc_upload_dir(): string {
    $d=CC_DATA_DIR.'/uploads';
    if(!is_dir($d) && !mkdir($d,0775,true) && !is_dir($d)) throw new RuntimeException('Could not create upload folder.');
    return $d;
}
function cc_save_image_upload(array $file,string $prefix): string {
    if(($file['error']??UPLOAD_ERR_NO_FILE)===UPLOAD_ERR_NO_FILE) throw new RuntimeException('Choose a picture first.');
    if(($file['error']??UPLOAD_ERR_OK)!==UPLOAD_ERR_OK) throw new RuntimeException('Picture upload failed.');
    if((int)($file['size']??0)>5*1024*1024) throw new RuntimeException('Picture must be 5 MB or smaller.');
    $tmp=(string)($file['tmp_name']??'');
    $info=@getimagesize($tmp); $mime=$info['mime']??'';
    $ext=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif'][$mime]??null;
    if(!$ext) throw new RuntimeException('Use a JPG, PNG, WEBP, or GIF picture.');
    $name=preg_replace('/[^a-z0-9_-]/i','',$prefix).'-'.bin2hex(random_bytes(8)).'.'.$ext;
    $path=cc_upload_dir().'/'.$name;
    if(!move_uploaded_file($tmp,$path)) throw new RuntimeException('Could not save the picture.');
    return 'uploads/'.$name;
}
function cc_delete_media_path(?string $rel): void {
    if(!$rel || !str_starts_with($rel,'uploads/')) return;
    $full=CC_DATA_DIR.'/'.$rel;
    if(is_file($full)) @unlink($full);
}
function cc_media_url(string $kind,int $id,?string $path=null): ?string {
    if(!$path) return null;
    $full=CC_DATA_DIR.'/'.$path;
    $v=is_file($full)?(string)filemtime($full):'0';
    return 'media.php?kind='.rawurlencode($kind).'&id='.$id.'&v='.rawurlencode($v);
}
