<?php
declare(strict_types=1);
require_once __DIR__ . '/db.php';

function cc_start_session(): void {
    if (session_status()===PHP_SESSION_NONE) {
        session_name(CC_SESSION_NAME);
        session_set_cookie_params([
            'lifetime'=>60*60*24*30,
            'path'=>'/',
            'secure'=>(!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off'),
            'httponly'=>true,
            'samesite'=>'Lax'
        ]);
        session_start();
    }
}

function cc_current_identity(): ?array {
    cc_start_session();
    if (!empty($_SESSION['cc_user_id'])) {
        $s=cc_db()->prepare('SELECT id,display_name,username,role,active FROM users WHERE id=? AND active=1');
        $s->execute([(int)$_SESSION['cc_user_id']]);
        if ($u=$s->fetch()) return ['type'=>'user','id'=>(int)$u['id'],'name'=>$u['display_name'],'role'=>$u['role'],'username'=>$u['username']];
    }
    $token=$_COOKIE[CC_PAIR_COOKIE] ?? '';
    if ($token!=='') {
        $hash=hash('sha256',$token);
        $s=cc_db()->prepare('SELECT id,name,active FROM locations WHERE device_token_hash=? AND active=1');
        $s->execute([$hash]);
        if ($l=$s->fetch()) {
            cc_db()->prepare('UPDATE locations SET last_seen_at=CURRENT_TIMESTAMP WHERE id=?')->execute([(int)$l['id']]);
            return ['type'=>'location','id'=>(int)$l['id'],'name'=>$l['name'],'role'=>'location'];
        }
    }
    return null;
}

function cc_require_identity(): array {
    $i=cc_current_identity();
    if (!$i) {
        if (str_contains($_SERVER['REQUEST_URI'] ?? '', 'api.php')) cc_json(['ok'=>false,'error'=>'Authentication required'],401);
        header('Location: index.php'); exit;
    }
    return $i;
}

function cc_require_admin(): array {
    $i=cc_require_identity();
    if ($i['type']!=='user' || $i['role']!=='admin') {
        http_response_code(403); echo 'Admin access required.'; exit;
    }
    return $i;
}

function cc_login(string $username,string $password): bool {
    cc_start_session();
    $s=cc_db()->prepare('SELECT id,password_hash,active FROM users WHERE lower(username)=lower(?)');
    $s->execute([trim($username)]);
    $u=$s->fetch();
    if (!$u || !$u['active'] || !password_verify($password,$u['password_hash'])) return false;
    $_SESSION['cc_user_id']=(int)$u['id'];
    session_regenerate_id(true);
    return true;
}

function cc_logout(): void {
    cc_start_session();
    $_SESSION=[];
    if (ini_get('session.use_cookies')) {
        $p=session_get_cookie_params();
        setcookie(session_name(),'',time()-42000,$p['path'],$p['domain']??'',(bool)$p['secure'],(bool)$p['httponly']);
    }
    session_destroy();
}

function cc_json(array $data,int $status=200): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($data,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE); exit;
}

function cc_user_group_ids(int $userId): array {
    $s=cc_db()->prepare("SELECT gm.group_id FROM group_members gm JOIN groups g ON g.id=gm.group_id WHERE gm.member_type='user' AND gm.member_id=? AND g.active=1 AND lower(g.name)<>'everyone' ORDER BY gm.group_id");
    $s->execute([$userId]);
    return array_map('intval',array_column($s->fetchAll(),'group_id'));
}

function cc_identity_group_ids(array $identity): array {
    if ($identity['type']==='user' && ($identity['role']??'')==='admin') {
        return array_map('intval',array_column(cc_db()->query("SELECT id FROM groups WHERE active=1 AND lower(name)<>'everyone' ORDER BY id")->fetchAll(),'id'));
    }
    $s=cc_db()->prepare("SELECT gm.group_id FROM group_members gm JOIN groups g ON g.id=gm.group_id WHERE gm.member_type=? AND gm.member_id=? AND g.active=1 AND lower(g.name)<>'everyone' ORDER BY gm.group_id");
    $s->execute([$identity['type'],$identity['id']]);
    return array_map('intval',array_column($s->fetchAll(),'group_id'));
}

function cc_identity_has_access(array $identity): bool {
    if ($identity['type']==='user' && ($identity['role']??'')==='admin') return true;
    if ($identity['type']==='location') return true;
    return count(cc_identity_group_ids($identity))>0;
}

function cc_require_access(): array {
    $i=cc_require_identity();
    if (!cc_identity_has_access($i)) {
        if (str_contains($_SERVER['REQUEST_URI'] ?? '', 'api.php')) cc_json(['ok'=>false,'error'=>'Your account is waiting for group access.'],403);
        http_response_code(403); echo 'Your account is waiting for group access.'; exit;
    }
    return $i;
}

function cc_shared_group_exists(array $identity,string $targetType,int $targetId): bool {
    if ($identity['type']==='user' && ($identity['role']??'')==='admin') return true;
    $s=cc_db()->prepare("SELECT 1 FROM group_members a JOIN group_members b ON b.group_id=a.group_id JOIN groups g ON g.id=a.group_id WHERE a.member_type=? AND a.member_id=? AND b.member_type=? AND b.member_id=? AND g.active=1 AND lower(g.name)<>'everyone' LIMIT 1");
    $s->execute([$identity['type'],$identity['id'],$targetType,$targetId]);
    return (bool)$s->fetchColumn();
}

function cc_user_led_group_ids(int $userId): array {
    $s=cc_db()->prepare("SELECT gl.group_id FROM group_leaders gl JOIN groups g ON g.id=gl.group_id WHERE gl.user_id=? AND g.active=1 AND lower(g.name)<>'everyone' ORDER BY g.name");
    $s->execute([$userId]);
    return array_map('intval',array_column($s->fetchAll(),'group_id'));
}

function cc_user_leads_group(int $userId,int $groupId): bool {
    $s=cc_db()->prepare("SELECT 1 FROM group_leaders gl JOIN groups g ON g.id=gl.group_id WHERE gl.user_id=? AND gl.group_id=? AND g.active=1 AND lower(g.name)<>'everyone' LIMIT 1");
    $s->execute([$userId,$groupId]);
    return (bool)$s->fetchColumn();
}

function cc_identity_can_manage_group(array $identity,int $groupId): bool {
    if (($identity['type']??'')!=='user') return false;
    if (($identity['role']??'')==='admin') return true;
    return cc_user_leads_group((int)$identity['id'],$groupId);
}

function cc_require_team_manager(): array {
    $i=cc_require_access();
    if (($i['type']??'')!=='user') { http_response_code(403); echo 'Team Leader access required.'; exit; }
    if (($i['role']??'')==='admin' || cc_user_led_group_ids((int)$i['id'])) return $i;
    http_response_code(403); echo 'Team Leader access required.'; exit;
}
