<?php
declare(strict_types=1);
require_once __DIR__.'/lib/bootstrap.php';
if(!cc_installed()){header('Location: setup.php');exit;}
$me=cc_require_team_manager();$db=cc_db();cc_start_session();
$flash=(string)($_SESSION['cc_team_flash']??'');$flashType=(string)($_SESSION['cc_team_flash_type']??'success');$inviteUrl=(string)($_SESSION['cc_team_invite_url']??'');
unset($_SESSION['cc_team_flash'],$_SESSION['cc_team_flash_type'],$_SESSION['cc_team_invite_url']);
function tv(string $k,string $d=''): string{return trim((string)($_POST[$k]??$d));}
function managed_group_ids(array $me): array{
    if(($me['role']??'')==='admin')return array_map('intval',array_column(cc_db()->query("SELECT id FROM groups WHERE active=1 AND lower(name)<>'everyone' ORDER BY name")->fetchAll(),'id'));
    return cc_user_led_group_ids((int)$me['id']);
}
function require_managed_group(array $me,int $gid): void{
    if($gid<=0||!cc_identity_can_manage_group($me,$gid))throw new RuntimeException('You do not manage that team.');
    $q=cc_db()->prepare("SELECT 1 FROM groups WHERE id=? AND active=1 AND lower(name)<>'everyone'");$q->execute([$gid]);if(!$q->fetchColumn())throw new RuntimeException('That team is not available.');
}
if($_SERVER['REQUEST_METHOD']==='POST'){
  try{
    $action=tv('action');$gid=(int)tv('group_id','0');if($action!=='')require_managed_group($me,$gid);
    if($action==='add_existing'){
      $uid=(int)tv('user_id','0');$u=$db->prepare("SELECT id,display_name FROM users WHERE id=? AND active=1");$u->execute([$uid]);$user=$u->fetch();if(!$user)throw new RuntimeException('Choose an active person.');
      cc_add_group_member($gid,'user',$uid);$flash=$user['display_name'].' added to the team.';
    }elseif($action==='remove_member'){
      $uid=(int)tv('user_id','0');if($uid<=0)throw new RuntimeException('Invalid person.');
      $roleQ=$db->prepare('SELECT role FROM users WHERE id=?');$roleQ->execute([$uid]);if($roleQ->fetchColumn()==='admin')throw new RuntimeException('Administrators cannot be removed by a Team Leader.');
      $lead=$db->prepare('SELECT 1 FROM group_leaders WHERE group_id=? AND user_id=?');$lead->execute([$gid,$uid]);if($lead->fetchColumn())throw new RuntimeException('Only an administrator can remove a Team Leader from their team.');
      $name=cc_identity_name('user',$uid);cc_remove_group_member($gid,'user',$uid);$flash=$name.' removed from the team.';
    }elseif($action==='create_invite'){
      $days=max(1,min(30,(int)tv('expires_days','7')));$raw=rtrim(strtr(base64_encode(random_bytes(32)),'+/','-_'),'=');$hash=hash('sha256',$raw);
      $db->beginTransaction();
      $db->prepare("INSERT INTO invites(token_hash,role,expires_at,max_uses,created_by) VALUES(?,'member',datetime('now',?),1,?)")->execute([$hash,'+'.$days.' days',$me['id']]);$iid=(int)$db->lastInsertId();
      $db->prepare('INSERT INTO invite_groups(invite_id,group_id) VALUES(?,?)')->execute([$iid,$gid]);
      $db->prepare("INSERT INTO audit_log(actor_type,actor_id,action,details) VALUES('user',?,'team_invite_created',?)")->execute([$me['id'],'Group '.$gid.' invite #'.$iid]);$db->commit();
      $inviteUrl=cc_base_url().'/invite.php?token='.rawurlencode($raw);$flash='Team invitation created. Copy the link below; it is shown only now.';
    }elseif($action==='revoke_invite'){
      $iid=(int)tv('invite_id','0');$q=$db->prepare('SELECT 1 FROM invites i JOIN invite_groups ig ON ig.invite_id=i.id WHERE i.id=? AND i.created_by=? AND ig.group_id=?');$q->execute([$iid,$me['id'],$gid]);if(!$q->fetchColumn()&&($me['role']??'')!=='admin')throw new RuntimeException('You can only revoke invitations you created for this team.');
      if(($me['role']??'')==='admin'){$q=$db->prepare('SELECT 1 FROM invite_groups WHERE invite_id=? AND group_id=?');$q->execute([$iid,$gid]);if(!$q->fetchColumn())throw new RuntimeException('Invitation not found for this team.');}
      $db->prepare('UPDATE invites SET active=0 WHERE id=?')->execute([$iid]);$flash='Team invitation revoked.';
    }
  }catch(Throwable $e){if($db->inTransaction())$db->rollBack();$flash=$e->getMessage();$flashType='error';}
  $_SESSION['cc_team_flash']=$flash;$_SESSION['cc_team_flash_type']=$flashType;if($inviteUrl!=='')$_SESSION['cc_team_invite_url']=$inviteUrl;header('Location: team.php');exit;
}
$ids=managed_group_ids($me);if(!$ids){http_response_code(403);echo 'No teams are assigned to you.';exit;}
$ph=implode(',',array_fill(0,count($ids),'?'));$q=$db->prepare("SELECT g.id,g.name,g.description,g.image_path FROM groups g WHERE g.id IN ($ph) ORDER BY g.name");$q->execute($ids);$groups=$q->fetchAll();
$allUsers=$db->query("SELECT id,display_name,username,avatar_path FROM users WHERE active=1 AND role<>'admin' ORDER BY display_name")->fetchAll();
$site=cc_setting('site_name','Church Communications');
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><link rel="stylesheet" href="assets/app.css"><title>Manage Teams — <?=cc_h($site)?></title></head><body class="admin-body"><header class="admin-top"><div><strong>Manage Teams</strong><small><?=cc_h($me['name'])?> • Team Leader</small></div><a class="button secondary compact" href="index.php">Back to App</a></header><main class="admin-main team-main">
<?php if($flash):?><div class="alert <?=$flashType?> sticky-flash"><?=cc_h($flash)?></div><?php endif;?>
<?php if($inviteUrl):?><section class="admin-section"><div class="invite-link-box"><strong>New team invitation</strong><input id="teamInviteLink" readonly value="<?=cc_h($inviteUrl)?>"><button type="button" class="primary compact" onclick="navigator.clipboard.writeText(document.getElementById('teamInviteLink').value);this.textContent='Copied'">Copy Link</button><small>The person who uses this link will automatically join this team.</small></div></section><?php endif;?>
<?php foreach($groups as $g):
  $gid=(int)$g['id'];$members=$db->prepare("SELECT u.id,u.display_name,u.username,u.role,u.avatar_path,CASE WHEN gl.user_id IS NULL THEN 0 ELSE 1 END is_leader FROM group_members gm JOIN users u ON u.id=gm.member_id AND gm.member_type='user' LEFT JOIN group_leaders gl ON gl.group_id=gm.group_id AND gl.user_id=u.id WHERE gm.group_id=? AND u.active=1 ORDER BY is_leader DESC,u.display_name");$members->execute([$gid]);$members=$members->fetchAll();$memberIds=array_flip(array_map(fn($x)=>(int)$x['id'],$members));
  $inv=$db->prepare("SELECT i.id,i.expires_at,i.uses,i.max_uses,i.active FROM invites i JOIN invite_groups ig ON ig.invite_id=i.id WHERE ig.group_id=? AND i.created_by=? ORDER BY i.id DESC LIMIT 20");$inv->execute([$gid,$me['id']]);$invites=$inv->fetchAll();$gavatar=cc_media_url('group',$gid,$g['image_path']??null);
?><section class="admin-section team-section"><div class="team-title"><?php if($gavatar):?><img class="team-hero-avatar" src="<?=cc_h($gavatar)?>" alt=""><?php else:?><span class="team-hero-avatar fallback"><?=cc_h(strtoupper(substr($g['name'],0,1)))?></span><?php endif;?><div><h2><?=cc_h($g['name'])?></h2><p><?=cc_h((string)($g['description']??''))?></p><small><?=count($members)?> people</small></div></div>
<div class="team-tools-grid"><div class="team-tool"><h3>Add Existing Person</h3><p class="muted">Add someone who already has a Church Communications account.</p><form method="post" class="stack"><input type="hidden" name="action" value="add_existing"><input type="hidden" name="group_id" value="<?=$gid?>"><label>Person<select name="user_id" required><option value="">Choose a person…</option><?php foreach($allUsers as $u):if(isset($memberIds[(int)$u['id']]))continue;?><option value="<?=$u['id']?>"><?=cc_h($u['display_name'])?> (@<?=cc_h($u['username'])?>)</option><?php endforeach;?></select></label><button class="primary">Add to <?=cc_h($g['name'])?></button></form></div>
<div class="team-tool"><h3>Invite New Person</h3><p class="muted">Send a private one-time link. Registration automatically adds them to this team.</p><form method="post" class="stack"><input type="hidden" name="action" value="create_invite"><input type="hidden" name="group_id" value="<?=$gid?>"><label>Link Expires<select name="expires_days"><option value="1">1 day</option><option value="7" selected>7 days</option><option value="30">30 days</option></select></label><button class="primary">Create Team Invite</button></form></div></div>
<h3 class="team-subhead">Team Roster</h3><div class="team-roster"><?php foreach($members as $u):$avatar=cc_media_url('user',(int)$u['id'],$u['avatar_path']??null);?><article class="team-member-row"><?php if($avatar):?><img class="admin-avatar" src="<?=cc_h($avatar)?>" alt=""><?php else:?><span class="admin-avatar fallback"><?=cc_h(strtoupper(substr($u['display_name'],0,1)))?></span><?php endif;?><div class="team-member-name"><strong><?=cc_h($u['display_name'])?></strong><small>@<?=cc_h($u['username'])?><?=$u['is_leader']?' • Team Leader':''?></small></div><?php if(!$u['is_leader']&&$u['role']!=='admin'):?><form method="post" onsubmit="return confirm('Remove <?=cc_h($u['display_name'])?> from <?=cc_h($g['name'])?>?');"><input type="hidden" name="action" value="remove_member"><input type="hidden" name="group_id" value="<?=$gid?>"><input type="hidden" name="user_id" value="<?=$u['id']?>"><button class="secondary compact">Remove</button></form><?php else:?><span class="leader-badge"><?= $u['role']==='admin'?'Admin':'Leader' ?></span><?php endif;?></article><?php endforeach;?></div>
<?php if($invites):?><h3 class="team-subhead">Your Recent Invites</h3><div class="team-invites"><?php foreach($invites as $iv):?><article><span>Invite #<?=$iv['id']?> • Expires <?=cc_h($iv['expires_at'])?> • <?=$iv['uses']?>/<?=$iv['max_uses']?> used</span><?php if($iv['active']&&$iv['uses']<$iv['max_uses']):?><form method="post"><input type="hidden" name="action" value="revoke_invite"><input type="hidden" name="group_id" value="<?=$gid?>"><input type="hidden" name="invite_id" value="<?=$iv['id']?>"><button class="secondary compact">Revoke</button></form><?php endif;?></article><?php endforeach;?></div><?php endif;?>
</section><?php endforeach;?></main></body></html>
