<?php
declare(strict_types=1);
require_once __DIR__.'/lib/bootstrap.php';
if (!cc_installed()) cc_json(['ok'=>false,'error'=>'Not installed'],503);
$me=cc_require_access(); $db=cc_db(); $action=$_GET['action']??$_POST['action']??'';
$input=[]; if (str_starts_with($_SERVER['CONTENT_TYPE']??'','application/json')) $input=json_decode(file_get_contents('php://input'),true)?:[]; else $input=$_POST;
function api_param(string $k,$d=null){global $input;return $input[$k]??$_GET[$k]??$d;}
function member_name(string $t,int $id): string { return cc_identity_name($t,$id); }
function api_member_avatar(string $t,int $id): ?string {
 global $db;
 if($t!=='user') return null;
 $q=$db->prepare('SELECT avatar_path FROM users WHERE id=?');$q->execute([$id]);$path=$q->fetchColumn();
 return cc_media_url('user',$id,is_string($path)?$path:null);
}
function api_group_avatar(int $gid): ?string {
 global $db;
 if($gid<=0)return null;$q=$db->prepare('SELECT image_path FROM groups WHERE id=?');$q->execute([$gid]);$path=$q->fetchColumn();
 return cc_media_url('group',$gid,is_string($path)?$path:null);
}

function sync_group_thread(int $threadId,int $groupId,array $me): void {
 global $db;
 $g=$db->prepare('SELECT name FROM groups WHERE id=? AND active=1');$g->execute([$groupId]);$name=$g->fetchColumn(); if(!$name)return;
 $db->prepare('DELETE FROM thread_members WHERE thread_id=?')->execute([$threadId]);
 $ins=$db->prepare('INSERT OR IGNORE INTO thread_members(thread_id,member_type,member_id) VALUES(?,?,?)');
 if(strcasecmp((string)$name,'Everyone')===0){
   foreach($db->query("SELECT DISTINCT u.id FROM users u WHERE u.active=1 AND (u.role='admin' OR EXISTS(SELECT 1 FROM group_members gm JOIN groups gx ON gx.id=gm.group_id WHERE gm.member_type='user' AND gm.member_id=u.id AND gx.active=1 AND lower(gx.name)<>'everyone'))")->fetchAll() as $x)$ins->execute([$threadId,'user',(int)$x['id']]);
   foreach($db->query('SELECT id FROM locations WHERE active=1')->fetchAll() as $x)$ins->execute([$threadId,'location',(int)$x['id']]);
 } else {
   $m=$db->prepare('SELECT member_type,member_id FROM group_members WHERE group_id=?');$m->execute([$groupId]);foreach($m->fetchAll() as $x)$ins->execute([$threadId,$x['member_type'],$x['member_id']]);
 }
 $ins->execute([$threadId,$me['type'],$me['id']]);
}
function find_direct_thread(array $members): ?int {
 global $db,$me;
 $self=$db->prepare("SELECT t.id FROM threads t JOIN thread_members tm ON tm.thread_id=t.id WHERE t.type='direct' AND tm.member_type=? AND tm.member_id=? ORDER BY t.updated_at DESC LIMIT 100");$self->execute([$me['type'],$me['id']]);
 $wanted=$members;sort($wanted);
 foreach($self->fetchAll() as $r){$s=$db->prepare('SELECT member_type||\':\'||member_id k FROM thread_members WHERE thread_id=?');$s->execute([$r['id']]);$have=array_column($s->fetchAll(),'k');sort($have);if($have===$wanted)return(int)$r['id'];}
 return null;
}
try {
 if($action==='config') cc_json(['ok'=>true,'identity'=>$me,'site_name'=>cc_setting('site_name'),'vapid_public'=>cc_setting('vapid_public'),'poll'=>(int)CC_POLL_SECONDS]);
 if($action==='directory'){
  if($me['type']==='user' && $me['role']==='admin'){
    $users=$db->query("SELECT id,display_name name,role,last_seen_at,avatar_path FROM users WHERE active=1 ORDER BY display_name")->fetchAll();
    $locs=$db->query("SELECT id,name,last_seen_at,paired_at FROM locations WHERE active=1 ORDER BY name")->fetchAll();
    $groups=$db->query("SELECT g.id,g.name,g.description,g.image_path,(SELECT count(*) FROM group_members gm WHERE gm.group_id=g.id) member_count FROM groups g WHERE g.active=1 ORDER BY g.name")->fetchAll();
  } else {
    $gids=cc_identity_group_ids($me);
    if(!$gids) cc_json(['ok'=>true,'people'=>[],'locations'=>[],'groups'=>[]]);
    $ph=implode(',',array_fill(0,count($gids),'?'));
    $q=$db->prepare("SELECT DISTINCT u.id,u.display_name name,u.role,u.last_seen_at,u.avatar_path FROM users u JOIN group_members gm ON gm.member_type='user' AND gm.member_id=u.id WHERE u.active=1 AND gm.group_id IN ($ph) AND NOT(?='user' AND u.id=?) ORDER BY u.display_name");$q->execute([...$gids,$me['type'],$me['id']]);$users=$q->fetchAll();
    $q=$db->prepare("SELECT DISTINCT l.id,l.name,l.last_seen_at,l.paired_at FROM locations l JOIN group_members gm ON gm.member_type='location' AND gm.member_id=l.id WHERE l.active=1 AND gm.group_id IN ($ph) AND NOT(?='location' AND l.id=?) ORDER BY l.name");$q->execute([...$gids,$me['type'],$me['id']]);$locs=$q->fetchAll();
    $q=$db->prepare("SELECT g.id,g.name,g.description,g.image_path,(SELECT count(*) FROM group_members x WHERE x.group_id=g.id) member_count FROM groups g WHERE g.active=1 AND g.id IN ($ph) ORDER BY g.name");$q->execute($gids);$groups=$q->fetchAll();
  }
  foreach($users as &$u){$u['avatar_url']=cc_media_url('user',(int)$u['id'],$u['avatar_path']??null);unset($u['avatar_path']);}unset($u);
  foreach($groups as &$g){$g['avatar_url']=cc_media_url('group',(int)$g['id'],$g['image_path']??null);unset($g['image_path']);}unset($g);
  cc_json(['ok'=>true,'people'=>$users,'locations'=>$locs,'groups'=>$groups]);
 }
 if($action==='threads'){
  $s=$db->prepare("SELECT t.id,t.type,t.title,t.group_id,t.updated_at,COALESCE((SELECT m.body FROM messages m WHERE m.thread_id=t.id ORDER BY m.id DESC LIMIT 1),'') last_body,COALESCE((SELECT m.id FROM messages m WHERE m.thread_id=t.id ORDER BY m.id DESC LIMIT 1),0) last_id,COALESCE(rr.last_read_message_id,0) last_read FROM threads t JOIN thread_members tm ON tm.thread_id=t.id LEFT JOIN read_receipts rr ON rr.thread_id=t.id AND rr.member_type=? AND rr.member_id=? WHERE tm.member_type=? AND tm.member_id=? ORDER BY t.updated_at DESC LIMIT 100");
  $s->execute([$me['type'],$me['id'],$me['type'],$me['id']]);$rows=$s->fetchAll();
  foreach($rows as &$r){
    $uc=$db->prepare('SELECT count(*) FROM messages WHERE thread_id=? AND id>?');$uc->execute([$r['id'],(int)$r['last_read']]);$r['unread']=(int)$uc->fetchColumn();
    $r['avatar_url']=!empty($r['group_id'])?api_group_avatar((int)$r['group_id']):null;
    if(!$r['title']) {$n=$db->prepare('SELECT member_type,member_id FROM thread_members WHERE thread_id=? AND NOT(member_type=? AND member_id=?) LIMIT 4');$n->execute([$r['id'],$me['type'],$me['id']]);$names=[];foreach($n->fetchAll() as $x)$names[]=member_name($x['member_type'],(int)$x['member_id']);$r['title']=$names?implode(', ',$names):'Conversation';}
    if(!$r['avatar_url'] && $r['type']==='direct'){$n=$db->prepare("SELECT member_type,member_id FROM thread_members WHERE thread_id=? AND NOT(member_type=? AND member_id=?) LIMIT 2");$n->execute([$r['id'],$me['type'],$me['id']]);$others=$n->fetchAll();if(count($others)===1)$r['avatar_url']=api_member_avatar($others[0]['member_type'],(int)$others[0]['member_id']);}
  }unset($r);
  cc_json(['ok'=>true,'threads'=>$rows]);
 }
 if($action==='messages'){
  $tid=(int)api_param('thread_id',0); if(!$tid||!cc_thread_has_member($tid,$me))cc_json(['ok'=>false,'error'=>'Conversation not found'],404);
  $after=max(0,(int)api_param('after_id',0)); if($after>0){$s=$db->prepare('SELECT * FROM messages WHERE thread_id=? AND id>? ORDER BY id ASC LIMIT 200');$s->execute([$tid,$after]);}
  else {$s=$db->prepare('SELECT * FROM (SELECT * FROM messages WHERE thread_id=? ORDER BY id DESC LIMIT 100) ORDER BY id ASC');$s->execute([$tid]);}
  $rows=$s->fetchAll();
  foreach($rows as &$m){
    $m['sender_name']=member_name($m['sender_type'],(int)$m['sender_id']);$m['sender_avatar_url']=api_member_avatar($m['sender_type'],(int)$m['sender_id']);
    $a=$db->prepare('SELECT member_type,member_id,acknowledged_at FROM acknowledgements WHERE message_id=?');$a->execute([$m['id']]);$m['acks']=$a->fetchAll();
    $seen=$db->prepare('SELECT member_type,member_id,updated_at seen_at FROM read_receipts WHERE thread_id=? AND last_read_message_id>=? AND NOT(member_type=? AND member_id=?) ORDER BY updated_at ASC');$seen->execute([$tid,$m['id'],$m['sender_type'],$m['sender_id']]);$m['seen']=[];
    foreach($seen->fetchAll() as $x){$x['name']=member_name($x['member_type'],(int)$x['member_id']);$x['avatar_url']=api_member_avatar($x['member_type'],(int)$x['member_id']);$m['seen'][]=$x;}
  }unset($m);
  $t=$db->prepare('SELECT title,type,group_id FROM threads WHERE id=?');$t->execute([$tid]);$thr=$t->fetch(); if(!$thr['title']){$n=$db->prepare('SELECT member_type,member_id FROM thread_members WHERE thread_id=? AND NOT(member_type=? AND member_id=?)');$n->execute([$tid,$me['type'],$me['id']]);$names=[];foreach($n->fetchAll() as $x)$names[]=member_name($x['member_type'],(int)$x['member_id']);$thr['title']=$names?implode(', ',$names):'Conversation';}
  $thr['avatar_url']=!empty($thr['group_id'])?api_group_avatar((int)$thr['group_id']):null;
  if(!$thr['avatar_url'] && $thr['type']==='direct'){$n=$db->prepare('SELECT member_type,member_id FROM thread_members WHERE thread_id=? AND NOT(member_type=? AND member_id=?) LIMIT 2');$n->execute([$tid,$me['type'],$me['id']]);$others=$n->fetchAll();if(count($others)===1)$thr['avatar_url']=api_member_avatar($others[0]['member_type'],(int)$others[0]['member_id']);}
  cc_json(['ok'=>true,'messages'=>$rows,'thread'=>$thr]);
 }
 if($action==='mark_read'){
  $tid=(int)api_param('thread_id',0);$mid=(int)api_param('message_id',0);if(!$tid||!$mid||!cc_thread_has_member($tid,$me))cc_json(['ok'=>false,'error'=>'Conversation not found'],404);
  $q=$db->prepare('SELECT 1 FROM messages WHERE id=? AND thread_id=?');$q->execute([$mid,$tid]);if(!$q->fetchColumn())cc_json(['ok'=>false,'error'=>'Message not found'],404);
  cc_touch_read($tid,$me,$mid);cc_json(['ok'=>true]);
 }
 if($action==='receipts'){
  $tid=(int)api_param('thread_id',0);if(!$tid||!cc_thread_has_member($tid,$me))cc_json(['ok'=>false,'error'=>'Conversation not found'],404);
  $q=$db->prepare('SELECT member_type,member_id,last_read_message_id,updated_at FROM read_receipts WHERE thread_id=?');$q->execute([$tid]);$receipts=[];
  foreach($q->fetchAll() as $x){$x['name']=member_name($x['member_type'],(int)$x['member_id']);$x['avatar_url']=api_member_avatar($x['member_type'],(int)$x['member_id']);$receipts[]=$x;}
  $a=$db->prepare('SELECT message_id,count(*) ack_count FROM acknowledgements WHERE message_id IN (SELECT id FROM messages WHERE thread_id=?) GROUP BY message_id');$a->execute([$tid]);$acks=[];foreach($a->fetchAll() as $x)$acks[(string)$x['message_id']]=(int)$x['ack_count'];
  cc_json(['ok'=>true,'receipts'=>$receipts,'acks'=>$acks]);
 }
 if($action==='start_thread'){
  $targets=api_param('targets',[]); if(!is_array($targets)||!$targets)cc_json(['ok'=>false,'error'=>'Choose at least one recipient'],422);
  $memberMap=[cc_member_key($me['type'],$me['id'])=>[$me['type'],$me['id']]]; $titleParts=[]; $singleGroup=null;
  foreach($targets as $k){
   if(preg_match('/^group:(\d+)$/',$k,$m)){$gid=(int)$m[1]; if(!($me['type']==='user'&&$me['role']==='admin') && !in_array($gid,cc_identity_group_ids($me),true))continue; $g=$db->prepare('SELECT id,name FROM groups WHERE id=? AND active=1');$g->execute([$gid]);$gr=$g->fetch();if(!$gr)continue;$titleParts[]=$gr['name']; if(count($targets)===1)$singleGroup=$gid;
     $gm=$db->prepare('SELECT member_type,member_id FROM group_members WHERE group_id=?');$gm->execute([$gid]);foreach($gm->fetchAll() as $x)$memberMap[cc_member_key($x['member_type'],(int)$x['member_id'])]=[$x['member_type'],(int)$x['member_id']];
   } elseif(preg_match('/^(user|location):(\d+)$/',$k,$m)){ $t=$m[1];$id=(int)$m[2]; if($t===$me['type']&&$id===$me['id'])continue; if(!cc_shared_group_exists($me,$t,$id))continue; $memberMap[$k]=[$t,$id];$titleParts[]=member_name($t,$id); }
  }
  if(count($memberMap)<2)cc_json(['ok'=>false,'error'=>'No valid recipients selected'],422);
  if($singleGroup){$q=$db->prepare('SELECT id FROM threads WHERE type=\'group\' AND group_id=? LIMIT 1');$q->execute([$singleGroup]);$tid=(int)($q->fetchColumn()?:0);if(!$tid){$db->prepare('INSERT INTO threads(type,title,group_id,created_by_type,created_by_id) VALUES(\'group\',?,?,?,?)')->execute([implode(', ',$titleParts),$singleGroup,$me['type'],$me['id']]);$tid=(int)$db->lastInsertId();}sync_group_thread($tid,$singleGroup,$me);
  } else {
    $keys=array_keys($memberMap);$tid=find_direct_thread($keys)??0;
    if(!$tid){$title=count($titleParts)>3 ? implode(', ',array_slice($titleParts,0,3)).' +'.(count($titleParts)-3) : implode(', ',$titleParts);$db->prepare('INSERT INTO threads(type,title,created_by_type,created_by_id) VALUES(\'direct\',?,?,?)')->execute([$title,$me['type'],$me['id']]);$tid=(int)$db->lastInsertId();$ins=$db->prepare('INSERT INTO thread_members(thread_id,member_type,member_id) VALUES(?,?,?)');foreach($memberMap as [$t,$id])$ins->execute([$tid,$t,$id]);}
  }
  cc_json(['ok'=>true,'thread_id'=>$tid]);
 }
 if($action==='send'){
  $tid=(int)api_param('thread_id',0);$body=trim((string)api_param('body',''));$priority=(string)api_param('priority','normal');if(!in_array($priority,['normal','important','urgent'],true))$priority='normal';
  if(!$tid||!cc_thread_has_member($tid,$me))cc_json(['ok'=>false,'error'=>'Conversation not found'],404);if($body==='')cc_json(['ok'=>false,'error'=>'Message is blank'],422);if(mb_strlen($body)>2000)cc_json(['ok'=>false,'error'=>'Message is too long'],422);
  $tr=$db->prepare('SELECT group_id,title FROM threads WHERE id=?');$tr->execute([$tid]);$thr=$tr->fetch();if(!empty($thr['group_id']))sync_group_thread($tid,(int)$thr['group_id'],$me);
  $db->prepare('INSERT INTO messages(thread_id,sender_type,sender_id,body,priority) VALUES(?,?,?,?,?)')->execute([$tid,$me['type'],$me['id'],$body,$priority]);$mid=(int)$db->lastInsertId();$db->prepare('UPDATE threads SET updated_at=CURRENT_TIMESTAMP WHERE id=?')->execute([$tid]);cc_touch_read($tid,$me,$mid);
  $mem=$db->prepare('SELECT member_type,member_id FROM thread_members WHERE thread_id=? AND NOT(member_type=? AND member_id=?)');$mem->execute([$tid,$me['type'],$me['id']]);
  $snippet=mb_strlen($body)>140?mb_substr($body,0,137).'…':$body; foreach($mem->fetchAll() as $x){cc_push_to_identity($x['member_type'],(int)$x['member_id'],['title'=>$me['name'],'body'=>$snippet,'url'=>'index.php?thread='.$tid,'priority'=>$priority,'tag'=>'thread-'.$tid]);}
  cc_json(['ok'=>true,'message_id'=>$mid]);
 }
 if($action==='ack'){$mid=(int)api_param('message_id',0);$s=$db->prepare('SELECT thread_id FROM messages WHERE id=?');$s->execute([$mid]);$tid=(int)($s->fetchColumn()?:0);if(!$tid||!cc_thread_has_member($tid,$me))cc_json(['ok'=>false,'error'=>'Message not found'],404);$db->prepare('INSERT OR IGNORE INTO acknowledgements(message_id,member_type,member_id) VALUES(?,?,?)')->execute([$mid,$me['type'],$me['id']]);cc_json(['ok'=>true]);}
 if($action==='subscribe_push'){$sub=api_param('subscription',[]);$endpoint=$sub['endpoint']??'';$p=$sub['keys']['p256dh']??'';$a=$sub['keys']['auth']??'';if(!$endpoint||!$p||!$a)cc_json(['ok'=>false,'error'=>'Invalid push subscription'],422);$s=$db->prepare('INSERT INTO push_subscriptions(member_type,member_id,endpoint,p256dh,auth,user_agent) VALUES(?,?,?,?,?,?) ON CONFLICT(endpoint) DO UPDATE SET member_type=excluded.member_type,member_id=excluded.member_id,p256dh=excluded.p256dh,auth=excluded.auth,user_agent=excluded.user_agent,updated_at=CURRENT_TIMESTAMP');$s->execute([$me['type'],$me['id'],$endpoint,$p,$a,$_SERVER['HTTP_USER_AGENT']??'']);cc_json(['ok'=>true]);}
 if($action==='unsubscribe_push'){$endpoint=(string)api_param('endpoint','');$db->prepare('DELETE FROM push_subscriptions WHERE endpoint=? AND member_type=? AND member_id=?')->execute([$endpoint,$me['type'],$me['id']]);cc_json(['ok'=>true]);}
 cc_json(['ok'=>false,'error'=>'Unknown action'],404);
} catch(Throwable $e){error_log('CC API: '.$e->getMessage());cc_json(['ok'=>false,'error'=>'Server error: '.$e->getMessage()],500);}
