<?php
declare(strict_types=1);
require_once __DIR__.'/lib/bootstrap.php';
require_once __DIR__.'/lib/updater.php';
if (!cc_installed()) { header('Location: setup.php'); exit; }
$me=cc_require_admin(); $db=cc_db(); cc_start_session();
$flash=(string)($_SESSION['cc_admin_flash']??''); $flashType=(string)($_SESSION['cc_admin_flash_type']??'success'); $newCode=(string)($_SESSION['cc_admin_new_code']??''); $newInviteUrl=(string)($_SESSION['cc_admin_invite_url']??''); $updateInfo=$_SESSION['cc_admin_update_info']??null;
unset($_SESSION['cc_admin_flash'],$_SESSION['cc_admin_flash_type'],$_SESSION['cc_admin_new_code'],$_SESSION['cc_admin_invite_url'],$_SESSION['cc_admin_update_info']);
function postv(string $k,string $d=''): string { return trim((string)($_POST[$k]??$d)); }
if (isset($_GET['backup'])) {
    $tmp=CC_DATA_DIR.'/backup-'.date('Ymd-His').'.sqlite'; @unlink($tmp);
    $db->exec("VACUUM INTO ".$db->quote($tmp));
    header('Content-Type: application/octet-stream'); header('Content-Disposition: attachment; filename="church-communications-backup-'.date('Y-m-d').'.sqlite"');
    header('Content-Length: '.filesize($tmp)); readfile($tmp); @unlink($tmp); exit;
}
if ($_SERVER['REQUEST_METHOD']==='POST') {
 try {
  $a=postv('action');
  if($a==='create_location'){
    $name=postv('name'); if($name==='')throw new RuntimeException('Enter a location name.');
    $dupe=$db->prepare('SELECT id,name FROM locations WHERE lower(name)=lower(?) LIMIT 1'); $dupe->execute([$name]);
    if($existing=$dupe->fetch()){
      $flash='“'.$existing['name'].'” already exists. Use its Generate Pair Code button instead of adding it again.'; $flashType='success';
    } else {
      $db->prepare('INSERT INTO locations(name) VALUES(?)')->execute([$name]); $flash='Location created.';
    }
  } elseif($a==='edit_location'){
    $id=(int)postv('id'); $name=postv('name');
    if($id<=0||$name==='')throw new RuntimeException('Choose a location and enter a name.');
    $exists=$db->prepare('SELECT name FROM locations WHERE id=?');$exists->execute([$id]);$oldName=$exists->fetchColumn();
    if($oldName===false)throw new RuntimeException('That location no longer exists.');
    $dupe=$db->prepare('SELECT id,name FROM locations WHERE lower(name)=lower(?) AND id<>? LIMIT 1');$dupe->execute([$name,$id]);
    if($existing=$dupe->fetch())throw new RuntimeException('The location “'.$existing['name'].'” already exists.');
    $db->prepare('UPDATE locations SET name=? WHERE id=?')->execute([$name,$id]);
    $db->prepare("INSERT INTO audit_log(actor_type,actor_id,action,details) VALUES('user',?,'location_renamed',?)")->execute([$me['id'],'Location #'.$id.' renamed from '.$oldName.' to '.$name]);
    $flash='Location renamed to '.$name.'.';
  } elseif($a==='delete_location'){
    $id=(int)postv('id');if($id<=0)throw new RuntimeException('Invalid location.');
    $q=$db->prepare('SELECT name FROM locations WHERE id=?');$q->execute([$id]);$name=$q->fetchColumn();if($name===false)throw new RuntimeException('That location no longer exists.');
    $db->beginTransaction();
    try{
      $db->prepare("DELETE FROM group_members WHERE member_type='location' AND member_id=?")->execute([$id]);
      $db->prepare("DELETE FROM thread_members WHERE member_type='location' AND member_id=?")->execute([$id]);
      $db->prepare("DELETE FROM read_receipts WHERE member_type='location' AND member_id=?")->execute([$id]);
      $db->prepare("DELETE FROM acknowledgements WHERE member_type='location' AND member_id=?")->execute([$id]);
      $db->prepare("DELETE FROM push_subscriptions WHERE member_type='location' AND member_id=?")->execute([$id]);
      $db->prepare('DELETE FROM locations WHERE id=?')->execute([$id]);
      $db->prepare("INSERT INTO audit_log(actor_type,actor_id,action,details) VALUES('user',?,'location_deleted',?)")->execute([$me['id'],'Deleted location '.$name.' (#'.$id.'). Existing message history was kept.']);
      $db->commit();
    }catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
    $flash='Location “'.$name.'” deleted. Existing message history was kept.';
  } elseif($a==='pair_code'){
    $id=(int)postv('id'); $code=(string)random_int(100000,999999); $hash=hash('sha256',$code);
    $db->prepare("UPDATE locations SET pairing_code_hash=?,pairing_expires_at=datetime('now','+15 minutes') WHERE id=?")->execute([$hash,$id]);
    $name=cc_identity_name('location',$id); $newCode=$code; $flash="Pairing code for $name: $code (expires in 15 minutes)";
  } elseif($a==='toggle_location'){
    $id=(int)postv('id'); $db->prepare('UPDATE locations SET active=1-active WHERE id=?')->execute([$id]); $flash='Location status updated.';
  } elseif($a==='unpair_location'){
    $id=(int)postv('id'); $db->prepare('UPDATE locations SET device_token_hash=NULL,paired_at=NULL,last_seen_at=NULL WHERE id=?')->execute([$id]); $flash='Location device unpaired.';
  } elseif($a==='create_user'){
    $name=postv('display_name');$username=postv('username');$pass=(string)($_POST['password']??'');$role=postv('role','member');
    if($name===''||$username===''||strlen($pass)<8)throw new RuntimeException('Name, username, and an 8+ character password are required.');
    if(!preg_match('/^[A-Za-z0-9._-]{3,40}$/',$username))throw new RuntimeException('Username must be 3–40 characters using letters, numbers, dot, dash, or underscore.');
    if(!in_array($role,['member','leader','admin'],true))$role='member';
    $dupe=$db->prepare('SELECT 1 FROM users WHERE lower(username)=lower(?) LIMIT 1');$dupe->execute([$username]);if($dupe->fetchColumn())throw new RuntimeException('That username already exists. Choose a different username.');
    $db->beginTransaction();
    $db->prepare('INSERT INTO users(display_name,username,password_hash,role) VALUES(?,?,?,?)')->execute([$name,$username,password_hash($pass,PASSWORD_DEFAULT),$role]); $uid=(int)$db->lastInsertId();
    $joinedGroups=[];$ins=$db->prepare("INSERT OR IGNORE INTO group_members(group_id,member_type,member_id) VALUES(?,'user',?)");
    foreach(($_POST['groups']??[]) as $gid){$gid=(int)$gid;if($gid>0){$ins->execute([$gid,$uid]);$joinedGroups[]=$gid;}}
    $db->commit();foreach($joinedGroups as $gid)cc_sync_group_threads($gid); $flash='Person account created.'.(empty($_POST['groups'])&&$role!=='admin'?' Waiting for group access.':'');
  } elseif($a==='toggle_user'){
    $id=(int)postv('id'); if($id===$me['id'])throw new RuntimeException('You cannot disable your own account.');
    $db->prepare('UPDATE users SET active=1-active WHERE id=?')->execute([$id]);$flash='Person status updated.';
  } elseif($a==='reset_password'){
    $id=(int)postv('id');$pass=(string)($_POST['password']??'');if(strlen($pass)<8)throw new RuntimeException('Password must be at least 8 characters.');
    $db->prepare('UPDATE users SET password_hash=? WHERE id=?')->execute([password_hash($pass,PASSWORD_DEFAULT),$id]);$flash='Password reset.';
  } elseif($a==='upload_user_avatar'){
    $id=(int)postv('id');$old=$db->prepare('SELECT avatar_path FROM users WHERE id=?');$old->execute([$id]);$oldPath=$old->fetchColumn()?:null;
    $path=cc_save_image_upload($_FILES['picture']??[],'user-'.$id);$db->prepare('UPDATE users SET avatar_path=? WHERE id=?')->execute([$path,$id]);cc_delete_media_path(is_string($oldPath)?$oldPath:null);$flash='Profile picture updated.';
  } elseif($a==='remove_user_avatar'){
    $id=(int)postv('id');$old=$db->prepare('SELECT avatar_path FROM users WHERE id=?');$old->execute([$id]);$oldPath=$old->fetchColumn()?:null;
    $db->prepare('UPDATE users SET avatar_path=NULL WHERE id=?')->execute([$id]);cc_delete_media_path(is_string($oldPath)?$oldPath:null);$flash='Profile picture removed.';
  } elseif($a==='create_group'){
    $name=postv('name'); if($name==='')throw new RuntimeException('Enter a group name.');
    $dupe=$db->prepare('SELECT id,name FROM groups WHERE lower(name)=lower(?) LIMIT 1');$dupe->execute([$name]);if($existing=$dupe->fetch())throw new RuntimeException('The group “'.$existing['name'].'” already exists.');
    $db->prepare('INSERT INTO groups(name,description) VALUES(?,?)')->execute([$name,postv('description')]);$flash='Group created.';
  } elseif($a==='save_group'){
    $gid=(int)postv('group_id'); if($gid<=0)throw new RuntimeException('Invalid group.');
    $db->beginTransaction();
    $db->prepare('DELETE FROM group_members WHERE group_id=?')->execute([$gid]);
    $ins=$db->prepare('INSERT OR IGNORE INTO group_members(group_id,member_type,member_id) VALUES(?,?,?)');
    foreach(($_POST['members']??[]) as $key){ if(!preg_match('/^(user|location):(\d+)$/',$key,$m))continue;$ins->execute([$gid,$m[1],(int)$m[2]]); }
    $leaders=$db->prepare('SELECT user_id FROM group_leaders WHERE group_id=?');$leaders->execute([$gid]);foreach($leaders->fetchAll() as $lr)$ins->execute([$gid,'user',(int)$lr['user_id']]);
    $db->commit();cc_sync_group_threads($gid);
    $flash='Group membership saved. Team Leaders stay in their assigned team automatically.';
  } elseif($a==='save_group_leaders'){
    $gid=(int)postv('group_id');if($gid<=0)throw new RuntimeException('Invalid group.');
    $gq=$db->prepare("SELECT name FROM groups WHERE id=? AND lower(name)<>'everyone'");$gq->execute([$gid]);$gname=$gq->fetchColumn();if($gname===false)throw new RuntimeException('Team Leaders cannot be assigned to Everyone.');
    $newIds=[];foreach(($_POST['leaders']??[]) as $uid){$uid=(int)$uid;if($uid>0)$newIds[$uid]=true;}
    $db->beginTransaction();
    $oldQ=$db->prepare('SELECT user_id FROM group_leaders WHERE group_id=?');$oldQ->execute([$gid]);$oldIds=array_map('intval',array_column($oldQ->fetchAll(),'user_id'));
    $db->prepare('DELETE FROM group_leaders WHERE group_id=?')->execute([$gid]);
    $leadIns=$db->prepare('INSERT INTO group_leaders(group_id,user_id) VALUES(?,?)');
    $memberIns=$db->prepare("INSERT OR IGNORE INTO group_members(group_id,member_type,member_id) VALUES(?,'user',?)");
    foreach(array_keys($newIds) as $uid){$uq=$db->prepare('SELECT role FROM users WHERE id=? AND active=1');$uq->execute([$uid]);$role=$uq->fetchColumn();if($role===false)continue;$leadIns->execute([$gid,$uid]);$memberIns->execute([$gid,$uid]);if($role!=='admin')$db->prepare("UPDATE users SET role='leader' WHERE id=?")->execute([$uid]);}
    foreach($oldIds as $uid){if(isset($newIds[$uid]))continue;$q=$db->prepare('SELECT 1 FROM group_leaders WHERE user_id=? LIMIT 1');$q->execute([$uid]);if(!$q->fetchColumn())$db->prepare("UPDATE users SET role='member' WHERE id=? AND role='leader'")->execute([$uid]);}
    $db->commit();cc_sync_group_threads($gid);$flash='Team Leaders saved for '.$gname.'.';
  } elseif($a==='upload_group_image'){
    $gid=(int)postv('group_id');$old=$db->prepare('SELECT image_path FROM groups WHERE id=?');$old->execute([$gid]);$oldPath=$old->fetchColumn()?:null;
    $path=cc_save_image_upload($_FILES['picture']??[],'group-'.$gid);$db->prepare('UPDATE groups SET image_path=? WHERE id=?')->execute([$path,$gid]);cc_delete_media_path(is_string($oldPath)?$oldPath:null);$flash='Group picture updated.';
  } elseif($a==='remove_group_image'){
    $gid=(int)postv('group_id');$old=$db->prepare('SELECT image_path FROM groups WHERE id=?');$old->execute([$gid]);$oldPath=$old->fetchColumn()?:null;
    $db->prepare('UPDATE groups SET image_path=NULL WHERE id=?')->execute([$gid]);cc_delete_media_path(is_string($oldPath)?$oldPath:null);$flash='Group picture removed.';
  } elseif($a==='create_invite'){
    $role=postv('role','member');if(!in_array($role,['member','leader'],true))$role='member';
    $days=max(1,min(90,(int)postv('expires_days','7')));$raw=rtrim(strtr(base64_encode(random_bytes(32)),'+/','-_'),'=');$hash=hash('sha256',$raw);
    $db->beginTransaction();
    $db->prepare("INSERT INTO invites(token_hash,role,expires_at,created_by) VALUES(?,?,datetime('now',?),?)")->execute([$hash,$role,'+'.$days.' days',$me['id']]);$iid=(int)$db->lastInsertId();
    $ig=$db->prepare('INSERT OR IGNORE INTO invite_groups(invite_id,group_id) VALUES(?,?)');foreach(($_POST['groups']??[]) as $gid){$gid=(int)$gid;if($gid>0)$ig->execute([$iid,$gid]);}
    $db->commit();$newInviteUrl=cc_base_url().'/invite.php?token='.rawurlencode($raw);$flash='Invite created. Copy the link below; it is shown only now.';
  } elseif($a==='revoke_invite'){
    $iid=(int)postv('id');$db->prepare('UPDATE invites SET active=0 WHERE id=?')->execute([$iid]);$flash='Invite revoked.';
  } elseif($a==='save_update_feed'){
    $url=postv('update_manifest_url');if($url!==''&&!preg_match('#^https://#i',$url))throw new RuntimeException('Update Feed URL must use HTTPS.');cc_set_setting('update_manifest_url',$url);$flash='Update feed saved.';
  } elseif($a==='check_update'){
    $updateInfo=cc_update_manifest();$flash=version_compare($updateInfo['version'],CC_VERSION,'>')?'Update '.$updateInfo['version'].' is available.':'Church Communications is up to date.';
  } elseif($a==='install_update'){
    $manifest=cc_update_manifest();$result=cc_install_update($manifest);$flash=$result['message'].($result['installed']?' Refresh Admin to load the new version.':'');
  } elseif($a==='save_settings'){
    $site=postv('site_name');if($site==='')throw new RuntimeException('Site name cannot be blank.'); cc_set_setting('site_name',$site);
    $days=max(1,(int)postv('retention_days','365'));cc_set_setting('retention_days',(string)$days);$flash='Settings saved.';
  } elseif($a==='cleanup'){
    $days=max(1,(int)cc_setting('retention_days','365'));$s=$db->prepare("DELETE FROM messages WHERE created_at < datetime('now', ?)");$s->execute(['-'.$days.' days']);$flash='Old messages cleaned up.';
  }
 } catch(Throwable $e){
   if(isset($db)&&$db->inTransaction())$db->rollBack();
   if($e instanceof PDOException && str_contains(strtolower($e->getMessage()),'unique constraint failed')){
     $flash='That name or username is already in use. Nothing was duplicated.';
   } else {$flash=$e->getMessage();}
   $flashType='error';
 }
 // Post/Redirect/Get prevents browser refresh/back from submitting an Admin action twice.
 $_SESSION['cc_admin_flash']=$flash; $_SESSION['cc_admin_flash_type']=$flashType;
 if($newCode!=='')$_SESSION['cc_admin_new_code']=$newCode;
 if($newInviteUrl!=='')$_SESSION['cc_admin_invite_url']=$newInviteUrl;
 if($updateInfo!==null)$_SESSION['cc_admin_update_info']=$updateInfo;
 header('Location: admin.php'); exit;
}
$locations=$db->query('SELECT * FROM locations ORDER BY name')->fetchAll();
$users=$db->query('SELECT id,display_name,username,role,active,last_seen_at,created_at,avatar_path FROM users ORDER BY display_name')->fetchAll();
$groups=$db->query('SELECT g.*, (SELECT count(*) FROM group_members gm WHERE gm.group_id=g.id) member_count FROM groups g ORDER BY name')->fetchAll();
$invites=$db->query("SELECT i.*,COALESCE((SELECT group_concat(g.name, ', ') FROM invite_groups ig JOIN groups g ON g.id=ig.group_id WHERE ig.invite_id=i.id),'Waiting for admin assignment') group_names FROM invites i ORDER BY i.id DESC LIMIT 50")->fetchAll();
$allMembers=[]; foreach($users as $u)$allMembers[]=['key'=>'user:'.$u['id'],'name'=>$u['display_name'],'kind'=>'Person'];foreach($locations as $l)$allMembers[]=['key'=>'location:'.$l['id'],'name'=>$l['name'],'kind'=>'Location'];
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><link rel="stylesheet" href="assets/app.css"><title>Admin — Church Communications</title></head><body class="admin-body"><header class="admin-top"><div><strong>Church Communications Admin</strong><small><?=cc_h(cc_setting('site_name','Church Communications'))?></small></div><a class="button secondary compact" href="index.php">Back to App</a></header><main class="admin-main">
<?php if($flash):?><div class="alert <?=$flashType?> sticky-flash"><?=cc_h($flash)?></div><?php endif;?>
<section class="admin-section"><div class="section-title"><div><h2>Locations</h2><p>Pair wall iPads and fixed stations with one-time codes.</p></div></div><form method="post" class="inline-form"><input type="hidden" name="action" value="create_location"><input name="name" placeholder="Green Room" required><button class="primary">Add Location</button></form><div class="admin-grid">
<?php foreach($locations as $l):?><article class="admin-card"><div class="status-dot <?=$l['active']?'online':'offline'?>"></div><h3><?=cc_h($l['name'])?></h3><p class="muted"><?= $l['device_token_hash'] ? 'Paired'.($l['last_seen_at']?' • Last seen '.cc_h($l['last_seen_at']):'') : 'Not paired' ?></p><form method="post" class="mini-reset"><input type="hidden" name="action" value="edit_location"><input type="hidden" name="id" value="<?=$l['id']?>"><input name="name" value="<?=cc_h($l['name'])?>" aria-label="Location name" required><button class="secondary compact">Save Name</button></form><div class="card-actions"><form method="post"><input type="hidden" name="action" value="pair_code"><input type="hidden" name="id" value="<?=$l['id']?>"><button class="primary compact">Generate Pair Code</button></form><form method="post"><input type="hidden" name="action" value="unpair_location"><input type="hidden" name="id" value="<?=$l['id']?>"><button class="secondary compact">Unpair</button></form><form method="post"><input type="hidden" name="action" value="toggle_location"><input type="hidden" name="id" value="<?=$l['id']?>"><button class="secondary compact"><?=$l['active']?'Disable':'Enable'?></button></form><form method="post" onsubmit="return confirm('Delete this location? It will be removed from groups and devices. Existing message history will be kept.');"><input type="hidden" name="action" value="delete_location"><input type="hidden" name="id" value="<?=$l['id']?>"><button class="secondary compact danger-button">Delete</button></form></div></article><?php endforeach;?></div></section>
<section class="admin-section"><div class="section-title"><div><h2>People</h2><p>Create accounts yourself or send a private invitation link. Public registration is disabled.</p></div></div>
<form method="post" class="form-grid"><input type="hidden" name="action" value="create_user"><label>Display Name<input name="display_name" required placeholder="Worship Leader"></label><label>Username<input name="username" required placeholder="worshipleader"></label><label>Password<input name="password" type="password" minlength="8" required></label><label>Account Level<select name="role"><option value="member">Member</option><option value="admin">Admin</option></select></label><fieldset class="wide-field"><legend>Give Group Access Now</legend><div class="member-checks compact-checks"><?php foreach($groups as $g): if(strcasecmp($g['name'],'Everyone')===0)continue;?><label><input type="checkbox" name="groups[]" value="<?=$g['id']?>"><span><strong><?=cc_h($g['name'])?></strong><small>Can see this group and shared directory members</small></span></label><?php endforeach;?></div><p class="muted">No group selected = the account can sign in but sees only “Waiting for Access.” Admin accounts are exempt.</p></fieldset><button class="primary">Add Person</button></form>
<div class="admin-grid"><?php foreach($users as $u): $ugs=$db->prepare("SELECT g.name FROM group_members gm JOIN groups g ON g.id=gm.group_id WHERE gm.member_type='user' AND gm.member_id=? AND lower(g.name)<>'everyone' ORDER BY g.name");$ugs->execute([$u['id']]);$ugn=array_column($ugs->fetchAll(),'name');$leadq=$db->prepare("SELECT g.name FROM group_leaders gl JOIN groups g ON g.id=gl.group_id WHERE gl.user_id=? ORDER BY g.name");$leadq->execute([$u['id']]);$leadNames=array_column($leadq->fetchAll(),'name');$uavatar=cc_media_url('user',(int)$u['id'],$u['avatar_path']??null);?><article class="admin-card"><div class="admin-person-head"><?php if($uavatar):?><img class="admin-avatar" src="<?=cc_h($uavatar)?>" alt=""><?php else:?><span class="admin-avatar fallback"><?=cc_h(strtoupper(substr($u['display_name'],0,1)))?></span><?php endif;?><div><h3><?=cc_h($u['display_name'])?></h3><p class="muted">@<?=cc_h($u['username'])?> • <?=cc_h(ucfirst($u['role']))?> • <?=$u['active']?'Active':'Disabled'?></p></div></div><p class="muted"><?= $u['role']==='admin' ? 'Full Admin Access' : ($ugn ? 'Groups: '.cc_h(implode(', ',$ugn)) : 'Waiting for group access') ?></p><?php if($leadNames):?><p class="leader-line">Team Leader: <?=cc_h(implode(', ',$leadNames))?></p><?php endif;?><form method="post" enctype="multipart/form-data" class="picture-form"><input type="hidden" name="action" value="upload_user_avatar"><input type="hidden" name="id" value="<?=$u['id']?>"><input type="file" name="picture" accept="image/jpeg,image/png,image/webp,image/gif" required><button class="secondary compact">Set Picture</button></form><div class="card-actions"><?php if($uavatar):?><form method="post"><input type="hidden" name="action" value="remove_user_avatar"><input type="hidden" name="id" value="<?=$u['id']?>"><button class="secondary compact">Remove Picture</button></form><?php endif;?><?php if($u['id']!=$me['id']):?><form method="post"><input type="hidden" name="action" value="toggle_user"><input type="hidden" name="id" value="<?=$u['id']?>"><button class="secondary compact"><?=$u['active']?'Disable':'Enable'?></button></form><?php endif;?></div><form method="post" class="mini-reset"><input type="hidden" name="action" value="reset_password"><input type="hidden" name="id" value="<?=$u['id']?>"><input name="password" type="password" minlength="8" placeholder="New password"><button class="secondary compact">Reset</button></form></article><?php endforeach;?></div></section>
<section class="admin-section"><div class="section-title"><div><h2>Invite Links</h2><p>Only people with an invitation you create can register. Invitations are one-time and expire automatically.</p></div></div>
<?php if($newInviteUrl):?><div class="invite-link-box"><strong>New invitation link</strong><input id="newInviteLink" readonly value="<?=cc_h($newInviteUrl)?>"><button type="button" class="primary compact" onclick="navigator.clipboard.writeText(document.getElementById('newInviteLink').value);this.textContent='Copied'">Copy Link</button><small>Copy it now. For security, the full token is not stored in readable form.</small></div><?php endif;?>
<form method="post" class="form-grid"><input type="hidden" name="action" value="create_invite"><label>Account Type<select name="role"><option value="member">Member</option></select></label><label>Link Expires<select name="expires_days"><option value="1">1 day</option><option value="7" selected>7 days</option><option value="30">30 days</option><option value="90">90 days</option></select></label><fieldset class="wide-field"><legend>Groups To Join Automatically</legend><div class="member-checks compact-checks"><?php foreach($groups as $g): if(strcasecmp($g['name'],'Everyone')===0)continue;?><label><input type="checkbox" name="groups[]" value="<?=$g['id']?>"><span><strong><?=cc_h($g['name'])?></strong><small>Optional</small></span></label><?php endforeach;?></div><p class="muted">If you choose no group, they can register but cannot see anything until you assign access.</p></fieldset><button class="primary">Create Invite Link</button></form>
<div class="admin-grid"><?php foreach($invites as $iv):?><article class="admin-card"><h3>Invite #<?=$iv['id']?></h3><p class="muted"><?=cc_h(ucfirst($iv['role']))?> • <?=cc_h($iv['group_names'])?></p><p class="muted">Expires <?=cc_h($iv['expires_at'])?> • Used <?=$iv['uses']?>/<?=$iv['max_uses']?> • <?=($iv['active']&&$iv['uses']<$iv['max_uses'])?'Active':'Closed'?></p><?php if($iv['active']&&$iv['uses']<$iv['max_uses']):?><form method="post"><input type="hidden" name="action" value="revoke_invite"><input type="hidden" name="id" value="<?=$iv['id']?>"><button class="secondary compact">Revoke Invite</button></form><?php endif;?></article><?php endforeach;?></div></section>
<section class="admin-section"><div class="section-title"><div><h2>Groups</h2><p>Message only the people and locations that belong to a team. Assign Team Leaders here; they can manage only their own teams.</p></div></div>
<form method="post" class="inline-form"><input type="hidden" name="action" value="create_group"><input name="name" placeholder="Youth Leaders" required><input name="description" placeholder="Optional description"><button class="primary">Add Group</button></form>
<div class="group-stack"><?php foreach($groups as $g):
 $gm=$db->prepare('SELECT member_type,member_id FROM group_members WHERE group_id=?');$gm->execute([$g['id']]);$selected=array_flip(array_map(fn($x)=>$x['member_type'].':'.$x['member_id'],$gm->fetchAll()));
 $gl=$db->prepare('SELECT user_id FROM group_leaders WHERE group_id=?');$gl->execute([$g['id']]);$leaderIds=array_map('intval',array_column($gl->fetchAll(),'user_id'));$leadersSelected=array_flip($leaderIds);
 $ln=$db->prepare('SELECT u.display_name FROM group_leaders gl JOIN users u ON u.id=gl.user_id WHERE gl.group_id=? ORDER BY u.display_name');$ln->execute([$g['id']]);$leaderNames=array_column($ln->fetchAll(),'display_name');
 $gavatar=cc_media_url('group',(int)$g['id'],$g['image_path']??null);
?><details class="group-editor"><summary><span class="group-summary-left"><?php if($gavatar):?><img class="mini-group-image" src="<?=cc_h($gavatar)?>" alt=""><?php else:?><span class="mini-group-image fallback"><?=cc_h(strtoupper(substr($g['name'],0,1)))?></span><?php endif;?><span><strong><?=cc_h($g['name'])?></strong><?php if($leaderNames):?><small>Leader<?=count($leaderNames)>1?'s':''?>: <?=cc_h(implode(', ',$leaderNames))?></small><?php endif;?></span></span><span><?=$g['member_count']?> members</span></summary>
<div class="group-picture-tools"><form method="post" enctype="multipart/form-data" class="picture-form"><input type="hidden" name="action" value="upload_group_image"><input type="hidden" name="group_id" value="<?=$g['id']?>"><input type="file" name="picture" accept="image/jpeg,image/png,image/webp,image/gif" required><button class="secondary compact">Set Group Picture</button></form><?php if($gavatar):?><form method="post"><input type="hidden" name="action" value="remove_group_image"><input type="hidden" name="group_id" value="<?=$g['id']?>"><button class="secondary compact">Remove Picture</button></form><?php endif;?></div>
<?php if(strcasecmp($g['name'],'Everyone')!==0):?><div class="leader-editor"><h3>Team Leaders</h3><p class="muted">Team Leaders can add/remove people and create invite links for this team only. Only Admin can assign or remove Team Leaders.</p><form method="post"><input type="hidden" name="action" value="save_group_leaders"><input type="hidden" name="group_id" value="<?=$g['id']?>"><div class="member-checks compact-checks"><?php foreach($users as $u):if(!$u['active']||$u['role']==='admin')continue;?><label><input type="checkbox" name="leaders[]" value="<?=$u['id']?>" <?=isset($leadersSelected[(int)$u['id']])?'checked':''?>><span><strong><?=cc_h($u['display_name'])?></strong><small>@<?=cc_h($u['username'])?></small></span></label><?php endforeach;?></div><button class="secondary">Save Team Leaders</button></form></div><?php endif;?>
<div class="group-members-editor"><h3>Members & Locations</h3><form method="post"><input type="hidden" name="action" value="save_group"><input type="hidden" name="group_id" value="<?=$g['id']?>"><div class="member-checks"><?php foreach($allMembers as $m):?><label><input type="checkbox" name="members[]" value="<?=cc_h($m['key'])?>" <?=isset($selected[$m['key']])?'checked':''?>><span><strong><?=cc_h($m['name'])?></strong><small><?=cc_h($m['kind'])?></small></span></label><?php endforeach;?></div><button class="primary">Save <?=cc_h($g['name'])?></button></form></div>
</details><?php endforeach;?></div></section>
<section class="admin-section"><div class="section-title"><div><h2>Website Updates</h2><p>Church Communications can download and install its own website updates. No manual ZIP download or FTP re-upload is needed.</p></div></div>
<form method="post" class="form-grid"><input type="hidden" name="action" value="save_update_feed"><label class="wide-field">Update Feed URL<input name="update_manifest_url" value="<?=cc_h(cc_setting('update_manifest_url',''))?>" placeholder="https://updates.example.com/church-communications/latest.json"></label><button class="secondary">Save Update Source</button></form>
<div class="system-actions"><form method="post"><input type="hidden" name="action" value="check_update"><button class="secondary">Check for Updates</button></form><form method="post" onsubmit="return confirm('Install the newest Church Communications update now? A SQLite backup will be created first.');"><input type="hidden" name="action" value="install_update"><button class="primary">Check & Install Update</button></form></div>
<?php if($updateInfo):?><div class="update-result"><strong>Latest: <?=cc_h($updateInfo['version'])?></strong><?php if(!empty($updateInfo['notes'])):?><p><?=cc_h((string)$updateInfo['notes'])?></p><?php endif;?></div><?php endif;?>
<p class="muted">Updates must come from an HTTPS feed with SHA-256 verified files or a verified ZIP. The updater preserves the entire <code>data</code> folder and backs up SQLite before installation.</p></section>
<section class="admin-section"><div class="section-title"><div><h2>System</h2><p>Portable settings and SQLite maintenance.</p></div></div><form method="post" class="form-grid"><input type="hidden" name="action" value="save_settings"><label>Church / Site Name<input name="site_name" value="<?=cc_h(cc_setting('site_name',''))?>" required></label><label>Keep Messages (days)<input name="retention_days" type="number" min="1" value="<?=cc_h(cc_setting('retention_days','365'))?>"></label><button class="primary">Save Settings</button></form><div class="system-actions"><a class="button secondary" href="admin.php?backup=1">Download SQLite Backup</a><form method="post"><input type="hidden" name="action" value="cleanup"><button class="secondary">Clean Old Messages Now</button></form></div><p class="muted">Version <?=CC_VERSION?> • Database: SQLite WAL mode • Domain detected automatically.</p></section>
</main></body></html>
