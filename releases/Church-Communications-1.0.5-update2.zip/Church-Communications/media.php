<?php
declare(strict_types=1);
require_once __DIR__.'/lib/bootstrap.php';
if(!cc_installed()){http_response_code(404);exit;}
$me=cc_require_access(); $db=cc_db();
$kind=(string)($_GET['kind']??''); $id=(int)($_GET['id']??0); $path=null;
if($id<=0){http_response_code(404);exit;}
if($kind==='user'){
    if(!($me['type']==='user'&&($me['role']??'')==='admin') && !($me['type']==='user'&&$me['id']===$id) && !cc_shared_group_exists($me,'user',$id)){http_response_code(403);exit;}
    $s=$db->prepare('SELECT avatar_path FROM users WHERE id=? AND active=1');$s->execute([$id]);$path=$s->fetchColumn();
} elseif($kind==='group'){
    if(!($me['type']==='user'&&($me['role']??'')==='admin')){
        $gids=cc_identity_group_ids($me);$allowed=in_array($id,$gids,true);
        if(!$allowed){$q=$db->prepare('SELECT 1 FROM threads t JOIN thread_members tm ON tm.thread_id=t.id WHERE t.group_id=? AND tm.member_type=? AND tm.member_id=? LIMIT 1');$q->execute([$id,$me['type'],$me['id']]);$allowed=(bool)$q->fetchColumn();}
        if(!$allowed){http_response_code(403);exit;}
    }
    $s=$db->prepare('SELECT image_path FROM groups WHERE id=? AND active=1');$s->execute([$id]);$path=$s->fetchColumn();
} else {http_response_code(404);exit;}
if(!$path || !is_string($path) || !str_starts_with($path,'uploads/')){http_response_code(404);exit;}
$file=CC_DATA_DIR.'/'.$path; if(!is_file($file)){http_response_code(404);exit;}
$info=@getimagesize($file); $mime=$info['mime']??'application/octet-stream';
header('Content-Type: '.$mime); header('Content-Length: '.filesize($file)); header('Cache-Control: private, max-age=86400');
readfile($file);
