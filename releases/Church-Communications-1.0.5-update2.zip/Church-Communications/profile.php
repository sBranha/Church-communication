<?php
declare(strict_types=1);
require_once __DIR__.'/lib/bootstrap.php';
if(!cc_installed()){header('Location: setup.php');exit;}
$me=cc_require_access(); if($me['type']!=='user'){header('Location: index.php');exit;}
$db=cc_db();$msg='';$err='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 try{
   if(($_POST['action']??'')==='upload'){
     $old=$db->prepare('SELECT avatar_path FROM users WHERE id=?');$old->execute([$me['id']]);$oldPath=$old->fetchColumn()?:null;
     $path=cc_save_image_upload($_FILES['picture']??[],'user-'.$me['id']);
     $db->prepare('UPDATE users SET avatar_path=? WHERE id=?')->execute([$path,$me['id']]);cc_delete_media_path(is_string($oldPath)?$oldPath:null);$msg='Profile picture updated.';
   } elseif(($_POST['action']??'')==='remove'){
     $old=$db->prepare('SELECT avatar_path FROM users WHERE id=?');$old->execute([$me['id']]);$oldPath=$old->fetchColumn()?:null;
     $db->prepare('UPDATE users SET avatar_path=NULL WHERE id=?')->execute([$me['id']]);cc_delete_media_path(is_string($oldPath)?$oldPath:null);$msg='Profile picture removed.';
   }
 }catch(Throwable $e){$err=$e->getMessage();}
}
$s=$db->prepare('SELECT display_name,username,avatar_path FROM users WHERE id=?');$s->execute([$me['id']]);$u=$s->fetch();
$avatar=cc_media_url('user',$me['id'],$u['avatar_path']??null);
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><link rel="stylesheet" href="assets/app.css"><title>My Profile</title></head><body class="login-page"><main class="login-shell"><section class="login-card profile-card"><a class="text-link profile-back" href="index.php">← Back to Church Communications</a><h1>My Profile</h1><div class="profile-preview"><?php if($avatar):?><img src="<?=cc_h($avatar)?>" alt="Profile picture"><?php else:?><span><?=cc_h(strtoupper(substr((string)$u['display_name'],0,1)))?></span><?php endif;?></div><h2><?=cc_h((string)$u['display_name'])?></h2><p class="muted">@<?=cc_h((string)$u['username'])?></p><?php if($msg):?><div class="alert success"><?=cc_h($msg)?></div><?php endif;?><?php if($err):?><div class="alert error"><?=cc_h($err)?></div><?php endif;?><form method="post" enctype="multipart/form-data" class="stack"><input type="hidden" name="action" value="upload"><label>Profile Picture<input type="file" name="picture" accept="image/jpeg,image/png,image/webp,image/gif" required></label><button class="primary big">Save Profile Picture</button></form><?php if($avatar):?><form method="post" class="stack"><input type="hidden" name="action" value="remove"><button class="secondary big">Remove Picture</button></form><?php endif;?></section></main></body></html>
