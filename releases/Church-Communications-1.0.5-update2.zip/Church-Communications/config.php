<?php
declare(strict_types=1);

define('CC_VERSION', '1.0.5');
define('CC_ROOT', __DIR__);
define('CC_DATA_DIR', CC_ROOT . '/data');
define('CC_DB_PATH', CC_DATA_DIR . '/church_communications.sqlite');
define('CC_SESSION_NAME', 'church_communications');
define('CC_PAIR_COOKIE', 'cc_device_token');
define('CC_PAIR_TTL_MINUTES', 15);
define('CC_POLL_SECONDS', 3);
