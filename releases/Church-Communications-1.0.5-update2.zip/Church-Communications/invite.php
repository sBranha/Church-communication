<?php
declare(strict_types=1);
require_once __DIR__.'/lib/bootstrap.php';
if (!cc_installed()) { header('Location: setup.php'); exit; }
cc_start_session();
$token=trim((string)($_GET['token']??$_POST['token']??''));
$error=''; $invite=null; $groups=[];
if ($token!=='') {
    $hash=hash('sha256',$token);
    $s=cc_db()->prepare("SELECT * FROM invites WHERE token_hash=? AND active=1 AND uses<max_uses AND expires_at>CURRENT_TIMESTAMP");
    $s->execute([$hash]); $invite=$s->fetch() ?: null;
    if ($invite) {
        $g=cc_db()->prepare("SELECT gr.id,gr.name FROM invite_groups ig JOIN groups gr ON gr.id=ig.group_id WHERE ig.invite_id=? AND gr.active=1 ORDER BY gr.name");
        $g->execute([$invite['id']]); $groups=$g->fetchAll();
    }
}
if ($_SERVER['REQUEST_METHOD']==='POST') {
    if (!$invite) $error='This invitation is invalid, expired, or has already been used.';
    else {
        $name=trim((string)($_POST['display_name']??''));
        $username=trim((string)($_POST['username']??''));
        $pass=(string)($_POST['password']??'');
        if ($name===''||$username===''||strlen($pass)<8) $error='Enter your name, username, and a password with at least 8 characters.';
        elseif (!preg_match('/^[A-Za-z0-9._-]{3,40}$/',$username)) $error='Username must be 3–40 characters using letters, numbers, dot, dash, or underscore.';
        else {
            $db=cc_db();
            try {
                $db->beginTransaction();
                $check=$db->prepare("SELECT * FROM invites WHERE id=? AND token_hash=? AND active=1 AND uses<max_uses AND expires_at>CURRENT_TIMESTAMP");
                $check->execute([$invite['id'],hash('sha256',$token)]); $fresh=$check->fetch();
                if (!$fresh) throw new RuntimeException('This invitation is no longer available.');
                $role=in_array($fresh['role'],['member','leader'],true)?$fresh['role']:'member';
                $db->prepare('INSERT INTO users(display_name,username,password_hash,role) VALUES(?,?,?,?)')->execute([$name,$username,password_hash($pass,PASSWORD_DEFAULT),$role]);
                $uid=(int)$db->lastInsertId();
                $q=$db->prepare('SELECT group_id FROM invite_groups WHERE invite_id=?');$q->execute([$fresh['id']]);
                $joinedGroups=[];$ins=$db->prepare("INSERT OR IGNORE INTO group_members(group_id,member_type,member_id) VALUES(?,'user',?)");
                foreach($q->fetchAll() as $row){$gid=(int)$row['group_id'];$ins->execute([$gid,$uid]);$joinedGroups[]=$gid;}
                $db->prepare('UPDATE invites SET uses=uses+1,active=CASE WHEN uses+1>=max_uses THEN 0 ELSE active END WHERE id=?')->execute([$fresh['id']]);
                $db->prepare("INSERT INTO audit_log(actor_type,actor_id,action,details) VALUES('user',?,'invite_registered',?)")->execute([$uid,'Invite #'.$fresh['id']]);
                $db->commit();
                foreach($joinedGroups as $gid)cc_sync_group_threads($gid);
                cc_login($username,$pass);
                header('Location: index.php?registered=1'); exit;
            } catch(Throwable $e) {
                if ($db->inTransaction()) $db->rollBack();
                $error=str_contains(strtolower($e->getMessage()),'unique')?'That username is already in use.':$e->getMessage();
            }
        }
    }
}
$site=cc_setting('site_name','Church Communications');
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><link rel="stylesheet" href="assets/app.css"><title>Invitation — <?=cc_h($site)?></title></head><body class="login-page"><main class="login-shell"><section class="login-card"><div class="brand-mark">CC</div><h1>Join <?=cc_h($site)?></h1>
<?php if(!$invite):?><div class="alert error">This invitation is invalid, expired, or has already been used.</div><a class="button secondary big" href="index.php">Back to Sign In</a>
<?php else:?><p class="muted">You were invited to Church Communications.</p><?php if($groups):?><div class="invite-groups"><strong>Access after registration:</strong><p><?=cc_h(implode(', ',array_column($groups,'name')))?></p></div><?php else:?><div class="alert success">Your account will be created, then wait for an administrator to assign group access.</div><?php endif;?><?php if($error):?><div class="alert error"><?=cc_h($error)?></div><?php endif;?>
<form method="post" class="stack"><input type="hidden" name="token" value="<?=cc_h($token)?>"><label>Your Name<input name="display_name" required autocomplete="name"></label><label>Choose Username<input name="username" required autocomplete="username" minlength="3" maxlength="40"></label><label>Choose Password<input name="password" type="password" minlength="8" required autocomplete="new-password"></label><button class="primary big">Create My Account</button></form><?php endif;?>
</section></main></body></html>
