<?php
declare(strict_types=1);
require_once __DIR__.'/config.php';
$checks=[
 'PHP 8.1+'=>version_compare(PHP_VERSION,'8.1.0','>='),
 'PDO'=>extension_loaded('pdo'),
 'PDO SQLite'=>extension_loaded('pdo_sqlite'),
 'OpenSSL'=>extension_loaded('openssl'),
 'cURL (push delivery)'=>extension_loaded('curl'),
 'Data folder writable'=>is_dir(CC_DATA_DIR)?is_writable(CC_DATA_DIR):is_writable(CC_ROOT),
 'HTTPS (required for remote push)'=>((!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')||in_array($_SERVER['HTTP_HOST']??'',['localhost','127.0.0.1'],true)),
];?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="stylesheet" href="assets/app.css"><title>Church Communications Health Check</title></head><body class="setup-page"><main class="setup-card"><div class="brand-mark">CC</div><h1>Server Health Check</h1><div class="stack"><?php foreach($checks as $name=>$ok):?><div class="alert <?=$ok?'success':'error'?>"><strong><?=$ok?'✓':'✕'?> <?=htmlspecialchars($name)?></strong></div><?php endforeach;?></div><a class="button primary big" href="setup.php">Continue to Setup</a></main></body></html>