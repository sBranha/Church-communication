<?php
declare(strict_types=1);
require_once __DIR__.'/lib/bootstrap.php';
if (!cc_installed()) { header('Location: setup.php'); exit; }
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $code=preg_replace('/\D/','',$_POST['code']??'');
    $hash=hash('sha256',$code);
    $s=cc_db()->prepare("SELECT id,name FROM locations WHERE pairing_code_hash=? AND pairing_expires_at>datetime('now') AND active=1");
    $s->execute([$hash]); $loc=$s->fetch();
    if (!$loc) $error='That pairing code is invalid or expired.';
    else {
        $token=cc_b64url_encode(random_bytes(32)); $th=hash('sha256',$token);
        cc_db()->prepare('UPDATE locations SET device_token_hash=?,pairing_code_hash=NULL,pairing_expires_at=NULL,paired_at=CURRENT_TIMESTAMP,last_seen_at=CURRENT_TIMESTAMP WHERE id=?')->execute([$th,$loc['id']]);
        setcookie(CC_PAIR_COOKIE,$token,[ 'expires'=>time()+60*60*24*365*5,'path'=>'/','secure'=>(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off'),'httponly'=>true,'samesite'=>'Lax']);
        header('Location: index.php'); exit;
    }
}
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="stylesheet" href="assets/app.css"><title>Pair Location</title></head><body class="login-page"><main class="login-shell"><section class="login-card"><div class="brand-mark">CC</div><h1>Pair This Device</h1><p class="muted">Enter the one-time code created in Admin for this location.</p><?php if($error):?><div class="alert error"><?=cc_h($error)?></div><?php endif;?><form method="post" class="stack"><label>6-Digit Pairing Code<input name="code" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" class="pair-code" autofocus required></label><button class="primary big">Pair Device</button></form><a class="text-link" href="index.php">Back to sign in</a></section></main></body></html>
