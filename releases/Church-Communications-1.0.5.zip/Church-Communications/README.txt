CHURCH COMMUNICATIONS 1.0.1
================================
Portable PHP + SQLite church communication system.

WHAT IT INCLUDES
- Location pairing with one-time 6-digit codes
- Personal user accounts for off-site access
- Direct/private messages
- Multi-recipient conversations
- Groups (Youth Leaders, Worship, Production, etc.)
- Normal / Important / Urgent messages
- Acknowledge button for Important/Urgent messages
- PWA install support for iPhone/iPad, Android, Windows, and Mac
- Standards-based Web Push notifications (HTTPS required)
- Kiosk mode for wall-mounted church iPads
- SQLite only, with WAL mode (no MySQL)
- Downloadable SQLite backup
- Invite-only registration (no public signup)
- One-time/expiring/revocable invitation links
- Users without group access see only Waiting for Access
- Admin one-click HTTPS update feed with SHA-256 verification
- Automatic pre-update SQLite backup and database migrations
- Domain-agnostic URLs: install on any compatible HTTPS domain/subfolder
- Newest messages at the bottom; scrolling up is never interrupted by new chat
- No visible scrollbars or scrolling sidebars

SERVER REQUIREMENTS
- PHP 8.1 or newer recommended
- PDO_SQLite enabled
- OpenSSL enabled
- cURL enabled for outbound push delivery
- HTTPS required for PWA push notifications (localhost excepted by browsers)
- The /data folder must be writable by PHP

INSTALL
1. Upload the entire Church Communications folder to your website.
2. Visit setup.php in a browser.
3. Enter the church/site name and create the first Admin account.
4. Sign in and open Admin.
5. Create locations such as Green Room and Tech Booth.
6. Tap Generate Pair Code for a location.
7. On that location's iPad, open the site -> Pair This Location Device -> enter the 6-digit code.
8. Add the site to the iPad Home Screen for app-style use.
9. Tap the bell in Church Communications and allow notifications.

IPHONE/IPAD INSTALL
Safari -> Share -> Add to Home Screen. Open the Home Screen app, then tap the bell to enable notifications.

SECURITY / DATA
Keep the /data directory protected and backed up. Included .htaccess files deny direct database access on Apache-compatible hosting. If your host uses Nginx, configure it to deny public access to /data.

BACKUPS
Admin -> System -> Download SQLite Backup.

REPAIR / REPLACE A LOCATION DEVICE
Admin -> Locations -> Unpair -> Generate Pair Code -> enter the new code on the replacement iPad.

VERSION
1.0.1


1.0.2 FIXES
- Friendly duplicate Location/Group/User handling instead of raw SQLite UNIQUE errors.
- Admin actions now use Post/Redirect/Get so refreshing the page does not submit the same action twice.


1.0.3 TEST UPDATE
- Profile pictures for people; Admin can set/remove, users can manage their own in My Profile.
- Small group pictures for chats such as Worship Team; shown in Directory, chat list, and chat header.
- Seen receipts show profile icons under messages and refresh while the chat is open.
- Seen is automatic when the conversation reaches the newest message; Acknowledge remains separate for Important/Urgent messages.
- Database migration adds avatar/image fields without replacing SQLite data.

1.0.4 — TEAM LEADERS
- Admin can assign one or more Team Leaders to each group.
- Team Leader is a per-group permission, not system-wide Admin access.
- Team Leaders get More > Manage My Teams.
- A Team Leader can add existing people, remove ordinary members, see the team roster, and create/revoke one-time invitation links for teams they lead.
- Team invite registration automatically places the new person into that specific group.
- Only Admin can assign/remove Team Leaders; Team Leaders cannot promote Admins or leaders.
- Group membership changes immediately update existing group-chat access.
- Includes 1.0.3 profile pictures, group pictures, and Seen-by profile icons.


1.0.5 — FEATURE RELEASE
- Adds profile pictures for people.
- Adds group pictures shown in group chat headers.
- Adds Seen-by profile icons while keeping Acknowledge separate.
- Adds per-group Team Leaders with limited team management and team invitation links.
- Keeps the David-style verified updater introduced in 1.0.4.
- Admin can rename locations and permanently delete old locations while preserving existing message history.
