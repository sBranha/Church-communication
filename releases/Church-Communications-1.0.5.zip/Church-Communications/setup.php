<?php
declare(strict_types=1);
require_once __DIR__.'/lib/bootstrap.php';
if (cc_installed()) { header('Location: index.php'); exit; }
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $church=trim($_POST['church_name']??'Church Communications');
    $name=trim($_POST['display_name']??'Administrator');
    $user=trim($_POST['username']??'admin');
    $pass=(string)($_POST['password']??'');
    if ($church===''||$name===''||$user===''||strlen($pass)<8) $error='Complete every field. Password must be at least 8 characters.';
    else {
        try {
            if (!is_dir(CC_DATA_DIR)) mkdir(CC_DATA_DIR,0775,true);
            $db=cc_db();
            $db->beginTransaction();
            $schema=<<<SQL
CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE users (
 id INTEGER PRIMARY KEY AUTOINCREMENT, display_name TEXT NOT NULL, username TEXT NOT NULL UNIQUE COLLATE NOCASE,
 password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'member', active INTEGER NOT NULL DEFAULT 1,
 avatar_path TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, last_seen_at TEXT
);
CREATE TABLE locations (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE COLLATE NOCASE, active INTEGER NOT NULL DEFAULT 1,
 pairing_code_hash TEXT, pairing_expires_at TEXT, device_token_hash TEXT, paired_at TEXT, last_seen_at TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE groups (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE COLLATE NOCASE, description TEXT,
 image_path TEXT,
 active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE group_members (
 group_id INTEGER NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
 member_type TEXT NOT NULL CHECK(member_type IN ('user','location')), member_id INTEGER NOT NULL,
 PRIMARY KEY(group_id,member_type,member_id)
);
CREATE TABLE group_leaders (
 group_id INTEGER NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(group_id,user_id)
);
CREATE TABLE threads (
 id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT NOT NULL DEFAULT 'direct', title TEXT, group_id INTEGER REFERENCES groups(id) ON DELETE SET NULL,
 created_by_type TEXT NOT NULL, created_by_id INTEGER NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE thread_members (
 thread_id INTEGER NOT NULL REFERENCES threads(id) ON DELETE CASCADE,
 member_type TEXT NOT NULL CHECK(member_type IN ('user','location')), member_id INTEGER NOT NULL,
 PRIMARY KEY(thread_id,member_type,member_id)
);
CREATE TABLE messages (
 id INTEGER PRIMARY KEY AUTOINCREMENT, thread_id INTEGER NOT NULL REFERENCES threads(id) ON DELETE CASCADE,
 sender_type TEXT NOT NULL CHECK(sender_type IN ('user','location')), sender_id INTEGER NOT NULL,
 body TEXT NOT NULL, priority TEXT NOT NULL DEFAULT 'normal' CHECK(priority IN ('normal','important','urgent')),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_messages_thread_id ON messages(thread_id,id);
CREATE TABLE read_receipts (
 thread_id INTEGER NOT NULL REFERENCES threads(id) ON DELETE CASCADE,
 member_type TEXT NOT NULL, member_id INTEGER NOT NULL, last_read_message_id INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(thread_id,member_type,member_id)
);
CREATE TABLE acknowledgements (
 message_id INTEGER NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
 member_type TEXT NOT NULL, member_id INTEGER NOT NULL, acknowledged_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(message_id,member_type,member_id)
);
CREATE TABLE push_subscriptions (
 id INTEGER PRIMARY KEY AUTOINCREMENT, member_type TEXT NOT NULL, member_id INTEGER NOT NULL,
 endpoint TEXT NOT NULL UNIQUE, p256dh TEXT NOT NULL, auth TEXT NOT NULL, user_agent TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE audit_log (
 id INTEGER PRIMARY KEY AUTOINCREMENT, actor_type TEXT, actor_id INTEGER, action TEXT NOT NULL, details TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE invites (
 id INTEGER PRIMARY KEY AUTOINCREMENT, token_hash TEXT NOT NULL UNIQUE, role TEXT NOT NULL DEFAULT 'member',
 expires_at TEXT NOT NULL, max_uses INTEGER NOT NULL DEFAULT 1, uses INTEGER NOT NULL DEFAULT 0,
 active INTEGER NOT NULL DEFAULT 1, created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE invite_groups (
 invite_id INTEGER NOT NULL REFERENCES invites(id) ON DELETE CASCADE,
 group_id INTEGER NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
 PRIMARY KEY(invite_id,group_id)
);
SQL;
            $db->exec($schema);
            $v=cc_generate_vapid();
            $settings=[
              'site_name'=>$church,'app_name'=>'Church Communications','accent'=>'#b32025','retention_days'=>'365',
              'version'=>CC_VERSION,'vapid_private_pem'=>$v['private_pem'],'vapid_public'=>$v['public'],
              'push_subject'=>'mailto:'.preg_replace('/[^a-z0-9._-]/i','',$user).'@'.($_SERVER['HTTP_HOST']??'localhost'),
              'installed_at'=>gmdate('c')
            ];
            $st=$db->prepare('INSERT INTO settings(key,value) VALUES(?,?)'); foreach($settings as $k=>$v2)$st->execute([$k,$v2]);
            $db->prepare('INSERT INTO users(display_name,username,password_hash,role) VALUES(?,?,?,\'admin\')')->execute([$name,$user,password_hash($pass,PASSWORD_DEFAULT)]);
            $db->prepare('INSERT INTO groups(name,description) VALUES(?,?)')->execute(['Everyone','System-wide broadcast group']);
            $db->commit();
            header('Location: index.php?installed=1'); exit;
        } catch(Throwable $e) {
            if (isset($db) && $db->inTransaction()) $db->rollBack();
            if (is_file(CC_DB_PATH)) @unlink(CC_DB_PATH);
            $error='Setup failed: '.$e->getMessage();
        }
    }
}
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title>Set Up Church Communications</title><link rel="stylesheet" href="assets/app.css"></head>
<body class="setup-page"><main class="setup-card"><div class="brand-mark">CC</div><h1>Church Communications</h1><p class="muted">Portable website/PWA setup. SQLite only — no MySQL required.</p>
<?php if($error):?><div class="alert error"><?=cc_h($error)?></div><?php endif;?>
<form method="post" class="stack"><label>Church / Organization Name<input name="church_name" required placeholder="Compassion City Church"></label><label>Your Display Name<input name="display_name" required placeholder="David"></label><label>Admin Username<input name="username" required autocomplete="username" value="admin"></label><label>Admin Password<input name="password" type="password" minlength="8" required autocomplete="new-password"></label><button class="primary big">Create Church Communications</button></form></main></body></html>
