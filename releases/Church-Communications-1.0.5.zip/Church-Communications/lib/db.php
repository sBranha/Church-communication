<?php
declare(strict_types=1);
require_once __DIR__ . '/../config.php';

function cc_db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    if (!is_dir(CC_DATA_DIR)) mkdir(CC_DATA_DIR, 0775, true);
    $pdo = new PDO('sqlite:' . CC_DB_PATH, null, null, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    $pdo->exec('PRAGMA foreign_keys = ON');
    $pdo->exec('PRAGMA journal_mode = WAL');
    $pdo->exec('PRAGMA synchronous = NORMAL');
    $pdo->exec('PRAGMA busy_timeout = 5000');
    return $pdo;
}

function cc_installed(): bool {
    if (!is_file(CC_DB_PATH)) return false;
    try {
        $db=cc_db();
        return (bool)$db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='settings'")->fetchColumn();
    } catch (Throwable $e) { return false; }
}

function cc_setting(string $key, ?string $default=null): ?string {
    if (!cc_installed()) return $default;
    $s=cc_db()->prepare('SELECT value FROM settings WHERE key=?');
    $s->execute([$key]);
    $v=$s->fetchColumn();
    return $v===false ? $default : (string)$v;
}

function cc_set_setting(string $key, string $value): void {
    $s=cc_db()->prepare('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value');
    $s->execute([$key,$value]);
}
