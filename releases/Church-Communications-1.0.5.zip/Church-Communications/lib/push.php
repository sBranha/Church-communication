<?php
declare(strict_types=1);
require_once __DIR__ . '/db.php';

function cc_b64url_encode(string $bin): string { return rtrim(strtr(base64_encode($bin), '+/', '-_'), '='); }
function cc_b64url_decode(string $s): string|false { return base64_decode(strtr($s.'===','-_','+/')); }

function cc_generate_vapid(): array {
    $res=openssl_pkey_new(['private_key_type'=>OPENSSL_KEYTYPE_EC,'curve_name'=>'prime256v1']);
    if (!$res) throw new RuntimeException('Unable to generate VAPID key.');
    openssl_pkey_export($res,$privatePem);
    $d=openssl_pkey_get_details($res);
    $pub="\x04".$d['ec']['x'].$d['ec']['y'];
    return ['private_pem'=>$privatePem,'public'=>cc_b64url_encode($pub)];
}

function cc_asn1_len(int $len): string {
    if ($len<128) return chr($len);
    $out=''; while($len>0){$out=chr($len&255).$out;$len>>=8;} return chr(0x80|strlen($out)).$out;
}
function cc_pem_from_raw_p256_public(string $raw): string {
    $prefix=hex2bin('3059301306072a8648ce3d020106082a8648ce3d030107034200');
    return "-----BEGIN PUBLIC KEY-----\n".chunk_split(base64_encode($prefix.$raw),64,"\n")."-----END PUBLIC KEY-----\n";
}
function cc_der_to_raw_ecdsa(string $der,int $partLen=32): string {
    $p=0; if (ord($der[$p++])!==0x30) throw new RuntimeException('Bad ECDSA signature');
    $l=ord($der[$p++]); if ($l&0x80){$n=$l&0x7f;$l=0;while($n--){$l=($l<<8)|ord($der[$p++]);}}
    if (ord($der[$p++])!==0x02) throw new RuntimeException('Bad ECDSA R');
    $lr=ord($der[$p++]); $r=substr($der,$p,$lr); $p+=$lr;
    if (ord($der[$p++])!==0x02) throw new RuntimeException('Bad ECDSA S');
    $ls=ord($der[$p++]); $s=substr($der,$p,$ls);
    $r=ltrim($r,"\0"); $s=ltrim($s,"\0");
    return str_pad($r,$partLen,"\0",STR_PAD_LEFT).str_pad($s,$partLen,"\0",STR_PAD_LEFT);
}
function cc_hkdf_extract(string $salt,string $ikm): string { return hash_hmac('sha256',$ikm,$salt,true); }
function cc_hkdf_expand(string $prk,string $info,int $len): string {
    $t='';$okm='';$i=1;
    while(strlen($okm)<$len){$t=hash_hmac('sha256',$t.$info.chr($i),$prk,true);$okm.=$t;$i++;}
    return substr($okm,0,$len);
}
function cc_origin_from_endpoint(string $endpoint): string {
    $p=parse_url($endpoint); if (!$p || empty($p['scheme']) || empty($p['host'])) throw new RuntimeException('Invalid push endpoint');
    $o=$p['scheme'].'://'.$p['host']; if (!empty($p['port'])) $o.=':'.$p['port']; return $o;
}
function cc_vapid_jwt(string $endpoint): string {
    $private=cc_setting('vapid_private_pem','');
    $pub=cc_setting('vapid_public','');
    if (!$private || !$pub) throw new RuntimeException('VAPID not configured');
    $header=cc_b64url_encode(json_encode(['typ'=>'JWT','alg'=>'ES256']));
    $claims=cc_b64url_encode(json_encode(['aud'=>cc_origin_from_endpoint($endpoint),'exp'=>time()+12*3600,'sub'=>cc_setting('push_subject','mailto:admin@example.invalid')]));
    $input=$header.'.'.$claims;
    if (!openssl_sign($input,$sig,$private,OPENSSL_ALGO_SHA256)) throw new RuntimeException('VAPID signing failed');
    return $input.'.'.cc_b64url_encode(cc_der_to_raw_ecdsa($sig));
}
function cc_encrypt_webpush(array $sub,string $payload): string {
    $clientPub=cc_b64url_decode($sub['p256dh']); $auth=cc_b64url_decode($sub['auth']);
    if ($clientPub===false || strlen($clientPub)!==65 || $auth===false) throw new RuntimeException('Invalid subscription keys');
    $clientKey=openssl_pkey_get_public(cc_pem_from_raw_p256_public($clientPub));
    $serverKey=openssl_pkey_new(['private_key_type'=>OPENSSL_KEYTYPE_EC,'curve_name'=>'prime256v1']);
    $details=openssl_pkey_get_details($serverKey); $serverPub="\x04".$details['ec']['x'].$details['ec']['y'];
    $shared=openssl_pkey_derive($clientKey,$serverKey,32);
    if ($shared===false) throw new RuntimeException('ECDH failed');
    $prkKey=cc_hkdf_extract($auth,$shared);
    $ikm=cc_hkdf_expand($prkKey,"WebPush: info\0".$clientPub.$serverPub,32);
    $salt=random_bytes(16); $prk=cc_hkdf_extract($salt,$ikm);
    $cek=cc_hkdf_expand($prk,"Content-Encoding: aes128gcm\0",16);
    $nonce=cc_hkdf_expand($prk,"Content-Encoding: nonce\0",12);
    $plain=$payload."\x02";
    $cipher=openssl_encrypt($plain,'aes-128-gcm',$cek,OPENSSL_RAW_DATA,$nonce,$tag,'',16);
    if ($cipher===false) throw new RuntimeException('Push encryption failed');
    return $salt.pack('N',4096).chr(strlen($serverPub)).$serverPub.$cipher.$tag;
}
function cc_send_push_subscription(array $sub,array $message): bool {
    if (!function_exists('curl_init')) return false;
    try {
        $payload=json_encode($message,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
        $body=cc_encrypt_webpush($sub,$payload);
        $jwt=cc_vapid_jwt($sub['endpoint']); $pub=cc_setting('vapid_public','');
        $ch=curl_init($sub['endpoint']);
        curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$body,CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>12,
            CURLOPT_HTTPHEADER=>['Content-Encoding: aes128gcm','Content-Type: application/octet-stream','TTL: 86400','Urgency: normal','Authorization: vapid t='.$jwt.', k='.$pub]]);
        curl_exec($ch); $code=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE); curl_close($ch);
        if (in_array($code,[404,410],true)) cc_db()->prepare('DELETE FROM push_subscriptions WHERE endpoint=?')->execute([$sub['endpoint']]);
        return $code>=200 && $code<300;
    } catch(Throwable $e) { error_log('Church Communications push: '.$e->getMessage()); return false; }
}
function cc_push_to_identity(string $type,int $id,array $message): void {
    $s=cc_db()->prepare('SELECT endpoint,p256dh,auth FROM push_subscriptions WHERE member_type=? AND member_id=?');
    $s->execute([$type,$id]);
    foreach($s->fetchAll() as $sub) cc_send_push_subscription($sub,$message);
}
