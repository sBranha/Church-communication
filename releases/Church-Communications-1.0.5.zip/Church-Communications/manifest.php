<?php
declare(strict_types=1); require_once __DIR__.'/lib/bootstrap.php'; header('Content-Type: application/manifest+json');
$name=cc_installed()?cc_setting('site_name','Church Communications'):'Church Communications';
echo json_encode(['name'=>$name.' Communications','short_name'=>'Church Comms','description'=>'Church-wide communications and location messaging','start_url'=>'./index.php','scope'=>'./','display'=>'standalone','background_color'=>'#111111','theme_color'=>'#151515','orientation'=>'any','icons'=>[['src'=>'icons/icon-192.png','sizes'=>'192x192','type'=>'image/png'],['src'=>'icons/icon-512.png','sizes'=>'512x512','type'=>'image/png']]],JSON_UNESCAPED_SLASHES);
